(globalThis["TURBOPACK"] || (globalThis["TURBOPACK"] = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/src/components/gaming/GamesPage.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "GamesPage",
    ()=>GamesPage
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/navigation.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$data$2f$games$2e$json$2e5b$json$5d2e$cjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/data/games.json.[json].cjs [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
;
const API_BASE = "https://restaurents-api.cylsys.com/api";
const CHECKOUT_URL = "https://app.thedesirelounge.com/checkout";
const COMPANY_ID = "0ffbe39e-abf8-4827-9107-1a04b39f3416";
const BRANCH_ID = "f4fb1d76-83a0-4965-86b5-63da28249dae";
function endpoint(type) {
    return type === "playstation" ? `${API_BASE}/Playstation/Playstationgamelist` : `${API_BASE}/BoardGame/Boardgamelist`;
}
function imageUrl(game) {
    return `https://restaurents-api.cylsys.com/${game.imagePath.replace(/^\/+/, "")}`;
}
function GamesPage({ type }) {
    _s();
    const searchParams = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useSearchParams"])();
    const [games, setGames] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$data$2f$games$2e$json$2e5b$json$5d2e$cjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"][type]);
    const [status, setStatus] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])("loading");
    const [query, setQuery] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])("");
    const companyId = searchParams.get("companyId") || COMPANY_ID;
    const branchId = searchParams.get("branchId") || BRANCH_ID;
    const title = type === "playstation" ? "PlayStation Sessions" : "Board Games";
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "GamesPage.useEffect": ()=>{
            const controller = new AbortController();
            const params = new URLSearchParams({
                companyId,
                branchId
            });
            fetch(`${endpoint(type)}?${params}`, {
                headers: {
                    Accept: "application/json"
                },
                signal: controller.signal
            }).then({
                "GamesPage.useEffect": (response)=>{
                    if (!response.ok) throw new Error(`Games API returned ${response.status}`);
                    return response.json();
                }
            }["GamesPage.useEffect"]).then({
                "GamesPage.useEffect": (payload)=>{
                    const records = Array.isArray(payload) ? payload : payload?.data || payload?.items || [];
                    if (records.length) setGames(records);
                    setStatus("ready");
                }
            }["GamesPage.useEffect"]).catch({
                "GamesPage.useEffect": (error)=>{
                    if (error instanceof DOMException && error.name === "AbortError") return;
                    console.warn("Games API unavailable; using bundled game list", error);
                    setStatus("fallback");
                }
            }["GamesPage.useEffect"]);
            return ({
                "GamesPage.useEffect": ()=>controller.abort()
            })["GamesPage.useEffect"];
        }
    }["GamesPage.useEffect"], [
        branchId,
        companyId,
        type
    ]);
    const visibleGames = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])({
        "GamesPage.useMemo[visibleGames]": ()=>games.filter({
                "GamesPage.useMemo[visibleGames]": (game)=>`${game.name} ${game.categoryName} ${game.difficulty}`.toLowerCase().includes(query.toLowerCase())
            }["GamesPage.useMemo[visibleGames]"])
    }["GamesPage.useMemo[visibleGames]"], [
        games,
        query
    ]);
    function checkout(game) {
        const params = new URLSearchParams(searchParams.toString());
        params.set("companyId", companyId);
        params.set("branchId", branchId);
        params.set("categoryName", type === "playstation" ? "PlayStation" : "Board Games");
        params.set("category", "GAMING");
        params.set("reservationCategory", "GAMING");
        params.set("bookingType", "Gaming Session");
        params.set("sessionType", "Gaming Session");
        params.set("gameId", game.id);
        params.set("gameName", game.name);
        params.set("players", `${game.playersMin}-${game.playersMax}`);
        params.set("duration", `${game.durationMin}-${game.durationMax} min`);
        params.set("difficulty", game.difficulty);
        params.set("reservationTitle", `Gaming: ${game.name}`);
        params.set("moduleId", "3e340f23-d842-47f0-98e8-b0d458dc22dd");
        params.set("extraDetails", JSON.stringify({
            ...game,
            type
        }));
        params.set("step", "about-you");
        params.set("hideSteps", "true");
        window.location.assign(`${CHECKOUT_URL}?${params}`);
    }
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("main", {
        className: "home-container",
        style: {
            paddingBlock: "4rem"
        },
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                className: "home-kicker home-kicker--line-right",
                children: "Desire Lounge Gaming"
            }, void 0, false, {
                fileName: "[project]/src/components/gaming/GamesPage.tsx",
                lineNumber: 96,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h1", {
                className: "home-heading",
                children: title
            }, void 0, false, {
                fileName: "[project]/src/components/gaming/GamesPage.tsx",
                lineNumber: 97,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                className: "home-copy",
                children: "Choose a game and reserve your session at the lounge."
            }, void 0, false, {
                fileName: "[project]/src/components/gaming/GamesPage.tsx",
                lineNumber: 98,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                style: {
                    display: "block",
                    maxWidth: 420,
                    margin: "2rem 0"
                },
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                        className: "sr-only",
                        children: "Search games"
                    }, void 0, false, {
                        fileName: "[project]/src/components/gaming/GamesPage.tsx",
                        lineNumber: 100,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                        className: "form-input",
                        type: "search",
                        placeholder: "Search games...",
                        value: query,
                        onChange: (event)=>setQuery(event.target.value)
                    }, void 0, false, {
                        fileName: "[project]/src/components/gaming/GamesPage.tsx",
                        lineNumber: 101,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/gaming/GamesPage.tsx",
                lineNumber: 99,
                columnNumber: 7
            }, this),
            status === "fallback" && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                role: "status",
                children: "Live game list unavailable. Showing the latest available game list."
            }, void 0, false, {
                fileName: "[project]/src/components/gaming/GamesPage.tsx",
                lineNumber: 103,
                columnNumber: 33
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "event-cards",
                "aria-live": "polite",
                children: visibleGames.map((game)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("article", {
                        className: "event-card",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "event-card__media",
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("img", {
                                    src: imageUrl(game),
                                    alt: game.name,
                                    width: 640,
                                    height: 400,
                                    loading: "lazy"
                                }, void 0, false, {
                                    fileName: "[project]/src/components/gaming/GamesPage.tsx",
                                    lineNumber: 108,
                                    columnNumber: 15
                                }, this)
                            }, void 0, false, {
                                fileName: "[project]/src/components/gaming/GamesPage.tsx",
                                lineNumber: 107,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "event-card__body",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                                        className: "event-card__title",
                                        children: game.name
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/gaming/GamesPage.tsx",
                                        lineNumber: 111,
                                        columnNumber: 15
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("ul", {
                                        className: "event-card__meta",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("li", {
                                                children: game.categoryName
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/gaming/GamesPage.tsx",
                                                lineNumber: 113,
                                                columnNumber: 17
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("li", {
                                                children: [
                                                    game.playersMin,
                                                    "-",
                                                    game.playersMax,
                                                    " players"
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/src/components/gaming/GamesPage.tsx",
                                                lineNumber: 114,
                                                columnNumber: 17
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("li", {
                                                children: [
                                                    game.durationMin,
                                                    "-",
                                                    game.durationMax,
                                                    " min"
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/src/components/gaming/GamesPage.tsx",
                                                lineNumber: 115,
                                                columnNumber: 17
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("li", {
                                                children: game.difficulty
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/gaming/GamesPage.tsx",
                                                lineNumber: 116,
                                                columnNumber: 17
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/src/components/gaming/GamesPage.tsx",
                                        lineNumber: 112,
                                        columnNumber: 15
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "event-card__actions",
                                        children: game.isAvailable ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                            className: "event-card__btn event-card__btn--solid",
                                            type: "button",
                                            onClick: ()=>checkout(game),
                                            children: "Reserve Session"
                                        }, void 0, false, {
                                            fileName: "[project]/src/components/gaming/GamesPage.tsx",
                                            lineNumber: 119,
                                            columnNumber: 37
                                        }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                            className: "event-card__btn event-card__btn--ended",
                                            children: "Currently Unavailable"
                                        }, void 0, false, {
                                            fileName: "[project]/src/components/gaming/GamesPage.tsx",
                                            lineNumber: 119,
                                            columnNumber: 168
                                        }, this)
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/gaming/GamesPage.tsx",
                                        lineNumber: 118,
                                        columnNumber: 15
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/components/gaming/GamesPage.tsx",
                                lineNumber: 110,
                                columnNumber: 13
                            }, this)
                        ]
                    }, game.id, true, {
                        fileName: "[project]/src/components/gaming/GamesPage.tsx",
                        lineNumber: 106,
                        columnNumber: 11
                    }, this))
            }, void 0, false, {
                fileName: "[project]/src/components/gaming/GamesPage.tsx",
                lineNumber: 104,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/src/components/gaming/GamesPage.tsx",
        lineNumber: 95,
        columnNumber: 5
    }, this);
}
_s(GamesPage, "HZvLv6KANhUG+/ia6VylEh0YvcM=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useSearchParams"]
    ];
});
_c = GamesPage;
var _c;
__turbopack_context__.k.register(_c, "GamesPage");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/data/games.json.[json].cjs [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {

module.exports = {
    "playstation": [
        {
            "id": "8f6e1cfd-73b7-483d-b032-41a90e5b39c9",
            "name": "Call of Duty",
            "categoryName": "Action",
            "playersMin": 1,
            "playersMax": 4,
            "durationMin": 20,
            "durationMax": 60,
            "difficulty": "Medium",
            "imagePath": "Image/Playstation/thedesire/CALLOFDUTY.webp",
            "isAvailable": true
        },
        {
            "id": "87e10429-797d-46ce-b3d3-25eb455237a9",
            "name": "EA Sports FC",
            "categoryName": "Sports",
            "playersMin": 1,
            "playersMax": 4,
            "durationMin": 15,
            "durationMax": 45,
            "difficulty": "Easy",
            "imagePath": "Image/Playstation/thedesire/EASPORTSFC.webp",
            "isAvailable": true
        },
        {
            "id": "b8b566d3-4963-437c-b226-621d7de619d7",
            "name": "Fortnite",
            "categoryName": "Multiplayer",
            "playersMin": 1,
            "playersMax": 4,
            "durationMin": 20,
            "durationMax": 45,
            "difficulty": "Easy",
            "imagePath": "Image/Playstation/thedesire/fortnite.webp",
            "isAvailable": true
        },
        {
            "id": "f3ebf148-f114-46f3-a772-c84d3cfec89c",
            "name": "Gran Turismo",
            "categoryName": "Racing",
            "playersMin": 1,
            "playersMax": 2,
            "durationMin": 20,
            "durationMax": 45,
            "difficulty": "Medium",
            "imagePath": "Image/Playstation/thedesire/GRANTURISMO.webp",
            "isAvailable": true
        },
        {
            "id": "befc07ec-8289-4c6a-9767-0c7c4b9b4674",
            "name": "Mortal Kombat",
            "categoryName": "Fighting",
            "playersMin": 1,
            "playersMax": 2,
            "durationMin": 10,
            "durationMax": 30,
            "difficulty": "Medium",
            "imagePath": "Image/Playstation/thedesire/mortal-kombat.webp",
            "isAvailable": false
        },
        {
            "id": "2ccfb3cb-8e70-46eb-99e5-f46094d794b1",
            "name": "NBA 2K",
            "categoryName": "Sports",
            "playersMin": 1,
            "playersMax": 4,
            "durationMin": 20,
            "durationMax": 45,
            "difficulty": "Easy",
            "imagePath": "Image/Playstation/thedesire/nba2k.webp",
            "isAvailable": true
        },
        {
            "id": "66089ff6-eac3-4631-bc1f-807613d82739",
            "name": "Need for Speed",
            "categoryName": "Racing",
            "playersMin": 1,
            "playersMax": 2,
            "durationMin": 15,
            "durationMax": 40,
            "difficulty": "Medium",
            "imagePath": "Image/Playstation/thedesire/nfs.webp",
            "isAvailable": true
        },
        {
            "id": "dfd73647-4c61-4471-99de-00e2f0f41c03",
            "name": "Spider-Man",
            "categoryName": "Adventure",
            "playersMin": 1,
            "playersMax": 1,
            "durationMin": 30,
            "durationMax": 60,
            "difficulty": "Easy",
            "imagePath": "Image/Playstation/thedesire/spiderman.webp",
            "isAvailable": true
        },
        {
            "id": "41a9f48d-b6e0-49e1-85ca-6db39ad4ce1f",
            "name": "Tekken",
            "categoryName": "Fighting",
            "playersMin": 1,
            "playersMax": 2,
            "durationMin": 10,
            "durationMax": 30,
            "difficulty": "Medium",
            "imagePath": "Image/Playstation/thedesire/tekken.webp",
            "isAvailable": true
        }
    ],
    "board-games": [
        {
            "id": "0a460def-c9a8-42df-98c6-0b9062777e45",
            "name": "Chess",
            "categoryName": "Strategy",
            "playersMin": 2,
            "playersMax": 2,
            "durationMin": 30,
            "durationMax": 60,
            "difficulty": "Medium",
            "imagePath": "Image/BoardGame/thedesire/chess.webp",
            "isAvailable": true
        },
        {
            "id": "c9ff5ed5-5fa4-4821-acaa-1bee3b4e40d7",
            "name": "Connect 4",
            "categoryName": "Two Players",
            "playersMin": 2,
            "playersMax": 2,
            "durationMin": 10,
            "durationMax": 20,
            "difficulty": "Easy",
            "imagePath": "Image/BoardGame/thedesire/connect4.webp",
            "isAvailable": false
        },
        {
            "id": "09c6eb40-1ea8-4759-0414-eadf4d0cbae8",
            "name": "Jenga",
            "categoryName": "Party",
            "playersMin": 1,
            "playersMax": 8,
            "durationMin": 20,
            "durationMax": 30,
            "difficulty": "Easy",
            "imagePath": "Image/BoardGame/thedesire/jenga.webp",
            "isAvailable": true
        },
        {
            "id": "c9c99e71-2d00-4727-b1e7-598154033718",
            "name": "Ludo",
            "categoryName": "Kids",
            "playersMin": 2,
            "playersMax": 4,
            "durationMin": 20,
            "durationMax": 40,
            "difficulty": "Easy",
            "imagePath": "Image/BoardGame/thedesire/ludo.webp",
            "isAvailable": true
        },
        {
            "id": "e641f7f0-8d80-4029-99d6-d4f714d6d401",
            "name": "Monopoly",
            "categoryName": "Family",
            "playersMin": 2,
            "playersMax": 8,
            "durationMin": 60,
            "durationMax": 180,
            "difficulty": "Easy",
            "imagePath": "Image/BoardGame/thedesire/monopoly.webp",
            "isAvailable": true
        },
        {
            "id": "b48801d9-159f-4706-bc26-20e7abec0125",
            "name": "Pictionary",
            "categoryName": "Party",
            "playersMin": 3,
            "playersMax": 16,
            "durationMin": 30,
            "durationMax": 60,
            "difficulty": "Easy",
            "imagePath": "Image/BoardGame/thedesire/pictionary.webp",
            "isAvailable": true
        },
        {
            "id": "e53651fa-de0e-4883-908b-493a8fca95ed",
            "name": "Scrabble",
            "categoryName": "Family",
            "playersMin": 2,
            "playersMax": 4,
            "durationMin": 45,
            "durationMax": 90,
            "difficulty": "Medium",
            "imagePath": "Image/BoardGame/thedesire/scrabble.webp",
            "isAvailable": true
        },
        {
            "id": "954ac6df-8228-4447-b8d6-acb0eeac00b9",
            "name": "Uno",
            "categoryName": "Card Games",
            "playersMin": 2,
            "playersMax": 10,
            "durationMin": 15,
            "durationMax": 30,
            "difficulty": "Easy",
            "imagePath": "Image/BoardGame/thedesire/uno.webp",
            "isAvailable": true
        }
    ]
};
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
]);

//# sourceMappingURL=src_056kphb._.js.map