(globalThis["TURBOPACK"] || (globalThis["TURBOPACK"] = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/src/components/common/HeroAnimate.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "HeroAnimate",
    ()=>HeroAnimate
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
function HeroAnimate({ children, className, bgSelector }) {
    _s();
    const ref = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "HeroAnimate.useEffect": ()=>{
            const root = ref.current;
            if (!root) return;
            const reduced = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
            const items = Array.from(root.querySelectorAll(".hero-anim"));
            if (reduced) {
                items.forEach({
                    "HeroAnimate.useEffect": (el)=>{
                        el.style.opacity = "1";
                    }
                }["HeroAnimate.useEffect"]);
                return;
            }
            if (bgSelector) {
                const bg = root.querySelector(bgSelector);
                if (bg) {
                    bg.animate([
                        {
                            transform: "scale(1.08)"
                        },
                        {
                            transform: "scale(1)"
                        }
                    ], {
                        duration: 2200,
                        easing: "cubic-bezier(0.16,1,0.3,1)",
                        fill: "forwards"
                    });
                }
            }
            items.forEach({
                "HeroAnimate.useEffect": (el, i)=>{
                    el.animate([
                        {
                            opacity: 0,
                            transform: "translateY(28px)"
                        },
                        {
                            opacity: 1,
                            transform: "translateY(0)"
                        }
                    ], {
                        duration: 900,
                        delay: 250 + i * 130,
                        easing: "cubic-bezier(0.22,1,0.36,1)",
                        fill: "forwards"
                    });
                }
            }["HeroAnimate.useEffect"]);
        }
    }["HeroAnimate.useEffect"], [
        bgSelector
    ]);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        ref: ref,
        className: className,
        children: children
    }, void 0, false, {
        fileName: "[project]/src/components/common/HeroAnimate.tsx",
        lineNumber: 57,
        columnNumber: 5
    }, this);
}
_s(HeroAnimate, "8uVE59eA/r6b92xF80p7sH8rXLk=");
_c = HeroAnimate;
var _c;
__turbopack_context__.k.register(_c, "HeroAnimate");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/events/EventsSchedule.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "EventsSchedule",
    ()=>EventsSchedule
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/navigation.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/image.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$data$2f$events$2d$schedule$2e$json$2e5b$json$5d2e$cjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/data/events-schedule.json.[json].cjs [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
;
;
const MENU_CHECKOUT_URL = "https://app.thedesirelounge.com/checkout";
const DEFAULT_COMPANY_ID = "0ffbe39e-abf8-4827-9107-1a04b39f3416";
const DEFAULT_BRANCH_ID = "f4fb1d76-83a0-4965-86b5-63da28249dae";
function parseLocalDate(iso) {
    const [y, m, d] = iso.split("-").map(Number);
    return new Date(y, m - 1, d);
}
function formatDisplayDate(iso) {
    const date = parseLocalDate(iso);
    const dd = String(date.getDate()).padStart(2, "0");
    const mon = date.toLocaleString("en-GB", {
        month: "short"
    });
    return `${dd} ${mon}`;
}
function getStatus(start, end, today) {
    const s = parseLocalDate(start);
    const e = parseLocalDate(end);
    e.setHours(23, 59, 59, 999);
    s.setHours(0, 0, 0, 0);
    if (today > e) return "past";
    if (today >= s && today <= e) return "live";
    return "upcoming";
}
function statusRank(status) {
    if (status === "live") return 0;
    if (status === "upcoming") return 1;
    return 2;
}
function EventsSchedule() {
    _s();
    const searchParams = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useSearchParams"])();
    const bookingContext = {
        companyId: searchParams.get("companyId") || DEFAULT_COMPANY_ID,
        branchId: searchParams.get("branchId") || DEFAULT_BRANCH_ID,
        sessionId: searchParams.get("sessionId") || searchParams.get("tableSessionId") || "",
        tableId: searchParams.get("tableId") || ""
    };
    const today = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])({
        "EventsSchedule.useMemo[today]": ()=>{
            const d = new Date();
            d.setHours(12, 0, 0, 0);
            return d;
        }
    }["EventsSchedule.useMemo[today]"], []);
    const events = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])({
        "EventsSchedule.useMemo[events]": ()=>{
            const items = __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$data$2f$events$2d$schedule$2e$json$2e5b$json$5d2e$cjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].events;
            return items.map({
                "EventsSchedule.useMemo[events]": (item)=>({
                        item,
                        status: getStatus(item.start, item.end, today)
                    })
            }["EventsSchedule.useMemo[events]"]).sort({
                "EventsSchedule.useMemo[events]": (a, b)=>{
                    const byStatus = statusRank(a.status) - statusRank(b.status);
                    if (byStatus !== 0) return byStatus;
                    if (a.status === "past") return b.item.start.localeCompare(a.item.start);
                    const byStart = a.item.start.localeCompare(b.item.start);
                    if (byStart !== 0) return byStart;
                    return a.item.category.localeCompare(b.item.category);
                }
            }["EventsSchedule.useMemo[events]"]);
        }
    }["EventsSchedule.useMemo[events]"], [
        today
    ]);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("section", {
        className: "sports-schedule",
        id: "events-schedule",
        "aria-labelledby": "events-schedule-heading",
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "home-container",
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "sports-schedule__intro",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                            className: "home-kicker home-kicker--line-right",
                            children: [
                                "Event Calendar",
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                    className: "home-kicker__line",
                                    "aria-hidden": "true"
                                }, void 0, false, {
                                    fileName: "[project]/src/components/events/EventsSchedule.tsx",
                                    lineNumber: 93,
                                    columnNumber: 13
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/src/components/events/EventsSchedule.tsx",
                            lineNumber: 91,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                            id: "events-schedule-heading",
                            className: "home-heading home-heading--split",
                            children: [
                                "Live, Upcoming & ",
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                    className: "text-gold",
                                    children: "Past"
                                }, void 0, false, {
                                    fileName: "[project]/src/components/events/EventsSchedule.tsx",
                                    lineNumber: 96,
                                    columnNumber: 34
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/src/components/events/EventsSchedule.tsx",
                            lineNumber: 95,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "home-divider",
                            "aria-hidden": "true"
                        }, void 0, false, {
                            fileName: "[project]/src/components/events/EventsSchedule.tsx",
                            lineNumber: 98,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                            className: "home-copy sports-schedule__copy",
                            children: "Browse current nights and previous performances at the lounge. Times may update closer to the event date."
                        }, void 0, false, {
                            fileName: "[project]/src/components/events/EventsSchedule.tsx",
                            lineNumber: 99,
                            columnNumber: 11
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/components/events/EventsSchedule.tsx",
                    lineNumber: 90,
                    columnNumber: 9
                }, this),
                events.length === 0 ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                    className: "sports-empty",
                    children: "No events scheduled right now. Please check back shortly."
                }, void 0, false, {
                    fileName: "[project]/src/components/events/EventsSchedule.tsx",
                    lineNumber: 105,
                    columnNumber: 11
                }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "event-cards",
                    "aria-live": "polite",
                    children: events.map(({ item, status })=>{
                        const isPast = status === "past";
                        const badgeLabel = status === "live" ? "Live" : isPast ? "Past" : "Upcoming";
                        const eventDetails = {
                            id: `${item.category}-${item.start}`,
                            name: item.title,
                            guest: item.guest || "",
                            dateStart: item.start,
                            dateEnd: item.end,
                            time: item.time,
                            venue: item.venue,
                            offer: item.offer || "",
                            description: item.description
                        };
                        const eventParams = new URLSearchParams({
                            companyId: bookingContext.companyId,
                            branchId: bookingContext.branchId,
                            ...bookingContext.sessionId ? {
                                sessionId: bookingContext.sessionId
                            } : {},
                            ...bookingContext.tableId ? {
                                tableId: bookingContext.tableId
                            } : {},
                            categoryName: "Events",
                            category: "EVENT",
                            reservationCategory: "EVENT",
                            eventName: item.title,
                            bookingType: "Event",
                            sessionType: "Event",
                            reservationTitle: item.title,
                            dateStart: item.start,
                            uaeTime: item.time,
                            extraDetails: JSON.stringify(eventDetails),
                            step: "about-you",
                            hideSteps: "true",
                            hideCardIcon: "true"
                        });
                        const checkoutHref = `${MENU_CHECKOUT_URL}?${eventParams.toString()}`;
                        return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("article", {
                            className: `event-card${isPast ? " event-card--past" : ""}`,
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "event-card__media",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                            className: `event-card__badge event-card__badge--${status}`,
                                            children: badgeLabel
                                        }, void 0, false, {
                                            fileName: "[project]/src/components/events/EventsSchedule.tsx",
                                            lineNumber: 146,
                                            columnNumber: 21
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                            src: `/images/events/${item.image.split("/").pop()}`,
                                            alt: item.imageAlt || item.title,
                                            width: item.imageWidth || 1024,
                                            height: item.imageHeight || 1024,
                                            loading: "lazy"
                                        }, void 0, false, {
                                            fileName: "[project]/src/components/events/EventsSchedule.tsx",
                                            lineNumber: 147,
                                            columnNumber: 21
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/src/components/events/EventsSchedule.tsx",
                                    lineNumber: 145,
                                    columnNumber: 19
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "event-card__body",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                                            className: "event-card__title",
                                            children: item.title
                                        }, void 0, false, {
                                            fileName: "[project]/src/components/events/EventsSchedule.tsx",
                                            lineNumber: 156,
                                            columnNumber: 21
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("ul", {
                                            className: "event-card__meta",
                                            children: [
                                                item.guest && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("li", {
                                                    children: [
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
                                                            viewBox: "0 0 24 24",
                                                            fill: "none",
                                                            stroke: "currentColor",
                                                            strokeWidth: "1.8",
                                                            "aria-hidden": "true",
                                                            children: [
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                                                                    d: "M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2"
                                                                }, void 0, false, {
                                                                    fileName: "[project]/src/components/events/EventsSchedule.tsx",
                                                                    lineNumber: 161,
                                                                    columnNumber: 29
                                                                }, this),
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("circle", {
                                                                    cx: "9",
                                                                    cy: "7",
                                                                    r: "4"
                                                                }, void 0, false, {
                                                                    fileName: "[project]/src/components/events/EventsSchedule.tsx",
                                                                    lineNumber: 162,
                                                                    columnNumber: 29
                                                                }, this),
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                                                                    d: "M22 21v-2a4 4 0 0 0-3-3.87M16 3.13a4 4 0 0 1 0 7.75"
                                                                }, void 0, false, {
                                                                    fileName: "[project]/src/components/events/EventsSchedule.tsx",
                                                                    lineNumber: 163,
                                                                    columnNumber: 29
                                                                }, this)
                                                            ]
                                                        }, void 0, true, {
                                                            fileName: "[project]/src/components/events/EventsSchedule.tsx",
                                                            lineNumber: 160,
                                                            columnNumber: 27
                                                        }, this),
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                            children: [
                                                                "Artist: ",
                                                                item.guest
                                                            ]
                                                        }, void 0, true, {
                                                            fileName: "[project]/src/components/events/EventsSchedule.tsx",
                                                            lineNumber: 165,
                                                            columnNumber: 27
                                                        }, this)
                                                    ]
                                                }, void 0, true, {
                                                    fileName: "[project]/src/components/events/EventsSchedule.tsx",
                                                    lineNumber: 159,
                                                    columnNumber: 25
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("li", {
                                                    children: [
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
                                                            viewBox: "0 0 24 24",
                                                            fill: "none",
                                                            stroke: "currentColor",
                                                            strokeWidth: "1.8",
                                                            "aria-hidden": "true",
                                                            children: [
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("rect", {
                                                                    x: "3",
                                                                    y: "4",
                                                                    width: "18",
                                                                    height: "18",
                                                                    rx: "2"
                                                                }, void 0, false, {
                                                                    fileName: "[project]/src/components/events/EventsSchedule.tsx",
                                                                    lineNumber: 170,
                                                                    columnNumber: 27
                                                                }, this),
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                                                                    d: "M16 2v4M8 2v4M3 10h18"
                                                                }, void 0, false, {
                                                                    fileName: "[project]/src/components/events/EventsSchedule.tsx",
                                                                    lineNumber: 171,
                                                                    columnNumber: 27
                                                                }, this)
                                                            ]
                                                        }, void 0, true, {
                                                            fileName: "[project]/src/components/events/EventsSchedule.tsx",
                                                            lineNumber: 169,
                                                            columnNumber: 25
                                                        }, this),
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                            children: [
                                                                "Date: ",
                                                                formatDisplayDate(item.start)
                                                            ]
                                                        }, void 0, true, {
                                                            fileName: "[project]/src/components/events/EventsSchedule.tsx",
                                                            lineNumber: 173,
                                                            columnNumber: 25
                                                        }, this)
                                                    ]
                                                }, void 0, true, {
                                                    fileName: "[project]/src/components/events/EventsSchedule.tsx",
                                                    lineNumber: 168,
                                                    columnNumber: 23
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("li", {
                                                    children: [
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
                                                            viewBox: "0 0 24 24",
                                                            fill: "none",
                                                            stroke: "currentColor",
                                                            strokeWidth: "1.8",
                                                            "aria-hidden": "true",
                                                            children: [
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("circle", {
                                                                    cx: "12",
                                                                    cy: "12",
                                                                    r: "9"
                                                                }, void 0, false, {
                                                                    fileName: "[project]/src/components/events/EventsSchedule.tsx",
                                                                    lineNumber: 177,
                                                                    columnNumber: 27
                                                                }, this),
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                                                                    d: "M12 7v5l3 2"
                                                                }, void 0, false, {
                                                                    fileName: "[project]/src/components/events/EventsSchedule.tsx",
                                                                    lineNumber: 178,
                                                                    columnNumber: 27
                                                                }, this)
                                                            ]
                                                        }, void 0, true, {
                                                            fileName: "[project]/src/components/events/EventsSchedule.tsx",
                                                            lineNumber: 176,
                                                            columnNumber: 25
                                                        }, this),
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                            children: [
                                                                "Time: ",
                                                                item.time
                                                            ]
                                                        }, void 0, true, {
                                                            fileName: "[project]/src/components/events/EventsSchedule.tsx",
                                                            lineNumber: 180,
                                                            columnNumber: 25
                                                        }, this)
                                                    ]
                                                }, void 0, true, {
                                                    fileName: "[project]/src/components/events/EventsSchedule.tsx",
                                                    lineNumber: 175,
                                                    columnNumber: 23
                                                }, this),
                                                item.offer && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("li", {
                                                    children: [
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
                                                            viewBox: "0 0 24 24",
                                                            fill: "none",
                                                            stroke: "currentColor",
                                                            strokeWidth: "1.8",
                                                            "aria-hidden": "true",
                                                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                                                                d: "M12 2l2.5 7h7l-5.5 4.2 2.1 6.8L12 16.5 5.9 20l2.1-6.8L2.5 9h7L12 2z"
                                                            }, void 0, false, {
                                                                fileName: "[project]/src/components/events/EventsSchedule.tsx",
                                                                lineNumber: 185,
                                                                columnNumber: 29
                                                            }, this)
                                                        }, void 0, false, {
                                                            fileName: "[project]/src/components/events/EventsSchedule.tsx",
                                                            lineNumber: 184,
                                                            columnNumber: 27
                                                        }, this),
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                            children: [
                                                                "Entry: ",
                                                                /free/i.test(item.offer) ? "Free" : item.offer
                                                            ]
                                                        }, void 0, true, {
                                                            fileName: "[project]/src/components/events/EventsSchedule.tsx",
                                                            lineNumber: 187,
                                                            columnNumber: 27
                                                        }, this)
                                                    ]
                                                }, void 0, true, {
                                                    fileName: "[project]/src/components/events/EventsSchedule.tsx",
                                                    lineNumber: 183,
                                                    columnNumber: 25
                                                }, this)
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/src/components/events/EventsSchedule.tsx",
                                            lineNumber: 157,
                                            columnNumber: 21
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "event-card__actions",
                                            children: isPast ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                className: "event-card__btn event-card__btn--ended",
                                                children: "Event Ended"
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/events/EventsSchedule.tsx",
                                                lineNumber: 193,
                                                columnNumber: 25
                                            }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("a", {
                                                href: checkoutHref,
                                                className: "event-card__btn event-card__btn--solid",
                                                children: "Book Event"
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/events/EventsSchedule.tsx",
                                                lineNumber: 195,
                                                columnNumber: 25
                                            }, this)
                                        }, void 0, false, {
                                            fileName: "[project]/src/components/events/EventsSchedule.tsx",
                                            lineNumber: 191,
                                            columnNumber: 21
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/src/components/events/EventsSchedule.tsx",
                                    lineNumber: 155,
                                    columnNumber: 19
                                }, this)
                            ]
                        }, item.title + item.start, true, {
                            fileName: "[project]/src/components/events/EventsSchedule.tsx",
                            lineNumber: 144,
                            columnNumber: 17
                        }, this);
                    })
                }, void 0, false, {
                    fileName: "[project]/src/components/events/EventsSchedule.tsx",
                    lineNumber: 107,
                    columnNumber: 11
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/events/EventsSchedule.tsx",
            lineNumber: 89,
            columnNumber: 7
        }, this)
    }, void 0, false, {
        fileName: "[project]/src/components/events/EventsSchedule.tsx",
        lineNumber: 88,
        columnNumber: 5
    }, this);
}
_s(EventsSchedule, "gjP4PG8fE6VGds1lytJqyjVE7JY=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useSearchParams"]
    ];
});
_c = EventsSchedule;
var _c;
__turbopack_context__.k.register(_c, "EventsSchedule");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/data/events-schedule.json.[json].cjs [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {

module.exports = {
    "events": [
        {
            "category": "janan-band",
            "month": "August",
            "start": "2026-08-09",
            "end": "2026-08-09",
            "title": "Janan Band Live",
            "description": "Janan Band presents a live performance featuring Ayaan Khan — a soulful evening of Sufi music and great vibes with premium shisha, exotic food, board games and PlayStations.",
            "guest": "Ayaan Khan",
            "time": "10:00 PM onwards",
            "venue": "Main Lounge",
            "offer": "Entry free",
            "image": "assets/images/events/janan-band-live.webp",
            "imageAlt": "Janan Band live performance featuring Ayaan Khan at DESIRE SHEESHA LOUNGE, Oud Metha",
            "imageWidth": 682,
            "imageHeight": 1024,
            "features": [
                "Live Sufi Music",
                "Premium Shisha",
                "Exotic Food",
                "Board Games & PlayStations"
            ]
        },
        {
            "category": "sufi-night",
            "month": "August",
            "start": "2026-08-14",
            "end": "2026-08-14",
            "title": "Sufi Night",
            "description": "A soulful evening of Sufi music and great vibes — live performance with premium shisha, exotic food, board games and PlayStations.",
            "guest": "Wagashaider",
            "time": "10:00 PM onwards",
            "venue": "Main Lounge",
            "offer": "Entry free",
            "image": "assets/images/events/sufi-night.webp",
            "imageAlt": "Sufi Night live performance featuring Wagashaider at DESIRE SHEESHA LOUNGE, Oud Metha",
            "imageWidth": 1024,
            "imageHeight": 1024,
            "features": [
                "Live Sufi Music",
                "Premium Shisha",
                "Exotic Food",
                "Board Games & PlayStations"
            ]
        },
        {
            "category": "live-music",
            "month": "August",
            "start": "2026-08-16",
            "end": "2026-08-16",
            "title": "Live Music Night",
            "description": "Live singing performance by Saffi Zulfiqar. Free entry, everyone welcome — with exotic food, premium shisha, comfy lounge, live sports and gaming.",
            "guest": "Saffi Zulfiqar",
            "time": "10:00 PM onwards",
            "venue": "Main Lounge",
            "offer": "Entry free",
            "image": "assets/images/events/live-music-night.webp",
            "imageAlt": "Live Music Night featuring Saffi Zulfiqar at DESIRE SHEESHA LOUNGE, Oud Metha",
            "imageWidth": 1024,
            "imageHeight": 1536,
            "features": [
                "Exotic Food",
                "Premium Shisha",
                "Comfy Lounge",
                "Live Music",
                "Live Sports",
                "Gaming Zone"
            ]
        }
    ]
};
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
]);

//# sourceMappingURL=src_18s8q1u._.js.map