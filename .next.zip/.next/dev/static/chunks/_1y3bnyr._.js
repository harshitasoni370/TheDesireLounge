(globalThis["TURBOPACK_CHUNK_LISTS"] || (globalThis["TURBOPACK_CHUNK_LISTS"] = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: ["static/chunks/src_app_globals_162hn9o.css","static/chunks/node_modules_next_1o573kz._.js","static/chunks/src_1j2vkk7._.js","static/chunks/src_18s8q1u._.js"],
    source: "entry"
});
