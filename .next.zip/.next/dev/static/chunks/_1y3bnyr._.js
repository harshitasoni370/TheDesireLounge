(globalThis["TURBOPACK_CHUNK_LISTS"] || (globalThis["TURBOPACK_CHUNK_LISTS"] = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: ["static/chunks/src_app_globals_162hn9o.css","static/chunks/node_modules_next_1o573kz._.js","static/chunks/src_0eg8lyg._.js","static/chunks/src_components_1jrhb91._.js"],
    source: "entry"
});
