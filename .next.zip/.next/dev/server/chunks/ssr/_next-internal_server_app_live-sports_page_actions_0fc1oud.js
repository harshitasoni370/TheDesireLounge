module.exports = [
"[project]/.next-internal/server/app/live-sports/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=_next-internal_server_app_live-sports_page_actions_0fc1oud.js.map