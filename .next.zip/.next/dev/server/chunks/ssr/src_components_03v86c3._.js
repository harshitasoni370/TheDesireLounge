module.exports = [
"[project]/src/components/common/HeroAnimate.tsx [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "HeroAnimate",
    ()=>HeroAnimate
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react.js [app-ssr] (ecmascript)");
"use client";
;
;
function HeroAnimate({ children, className, bgSelector }) {
    const ref = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useRef"])(null);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useEffect"])(()=>{
        const root = ref.current;
        if (!root) return;
        const reduced = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
        const items = Array.from(root.querySelectorAll(".hero-anim"));
        if (reduced) {
            items.forEach((el)=>{
                el.style.opacity = "1";
            });
            return;
        }
        if (bgSelector) {
            const bg = root.querySelector(bgSelector);
            if (bg) {
                bg.animate([
                    {
                        transform: "scale(1.08)"
                    },
                    {
                        transform: "scale(1)"
                    }
                ], {
                    duration: 2200,
                    easing: "cubic-bezier(0.16,1,0.3,1)",
                    fill: "forwards"
                });
            }
        }
        items.forEach((el, i)=>{
            el.animate([
                {
                    opacity: 0,
                    transform: "translateY(28px)"
                },
                {
                    opacity: 1,
                    transform: "translateY(0)"
                }
            ], {
                duration: 900,
                delay: 250 + i * 130,
                easing: "cubic-bezier(0.22,1,0.36,1)",
                fill: "forwards"
            });
        });
    }, [
        bgSelector
    ]);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        ref: ref,
        className: className,
        children: children
    }, void 0, false, {
        fileName: "[project]/src/components/common/HeroAnimate.tsx",
        lineNumber: 57,
        columnNumber: 5
    }, this);
}
}),
"[project]/src/components/events/EventsSchedule.tsx [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "EventsSchedule",
    ()=>EventsSchedule
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/navigation.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$site$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/site.ts [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$providers$2f$SiteConfigProvider$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/providers/SiteConfigProvider.tsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$site$2d$config$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/site-config.ts [app-ssr] (ecmascript)");
"use client";
;
;
;
;
;
;
const API_BASE = `${__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$site$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["EVENTS_API_PROXY_BASE_URL"]}/api`;
function parseLocalDate(iso) {
    const [y, m, d] = iso.split("-").map(Number);
    return new Date(y, m - 1, d);
}
function formatDisplayDate(iso) {
    const date = parseLocalDate(iso);
    const dd = String(date.getDate()).padStart(2, "0");
    const mon = date.toLocaleString("en-GB", {
        month: "short"
    });
    return `${dd} ${mon}`;
}
function formatTimeFromDatetime(dtm) {
    if (!dtm) return "10:00 PM onwards";
    const t = dtm.split(" ")[1];
    if (!t) return "10:00 PM onwards";
    const [hh, mm] = t.split(":").map(Number);
    if (isNaN(hh) || isNaN(mm)) return "10:00 PM onwards";
    const suffix = hh >= 12 ? "PM" : "AM";
    const hour12 = (hh + 11) % 12 + 1;
    return `${String(hour12).padStart(2, "0")}:${String(mm).padStart(2, "0")} ${suffix} onwards`;
}
function dateOnlyFromDatetime(dtm) {
    if (!dtm) return "";
    const d = dtm.split(" ")[0];
    return d || "";
}
function getStatus(start, end, today) {
    const s = parseLocalDate(start);
    const e = end ? parseLocalDate(end) : parseLocalDate(start);
    e.setHours(23, 59, 59, 999);
    s.setHours(0, 0, 0, 0);
    if (today > e) return "past";
    if (today >= s && today <= e) return "live";
    return "upcoming";
}
function statusRank(status) {
    if (status === "live") return 0;
    if (status === "upcoming") return 1;
    return 2;
}
function slugify(text) {
    return text.toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/(^-|-$)/g, "");
}
function resolveEventImage(apiImagePath, site) {
    if (apiImagePath && apiImagePath.trim()) {
        return {
            src: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$site$2d$config$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["getAssetUrl"])(apiImagePath, site),
            width: 1024,
            height: 1024
        };
    }
    return {
        src: "",
        width: 1024,
        height: 1024
    };
}
function mapApiToEventItem(master, map, site) {
    const start = dateOnlyFromDatetime(map.dtmStartDatetime);
    const end = dateOnlyFromDatetime(map.dtmEndDatetime) || start;
    const startDate = parseLocalDate(start);
    const month = startDate.toLocaleString("en-GB", {
        month: "long"
    });
    const image = resolveEventImage(map.strImagePath, site);
    return {
        category: slugify(master.strEventType || master.eventName),
        month,
        start,
        end,
        title: master.eventName,
        description: (master.strDescription || "").replace(/Fumes\s*&\s*Flavours/gi, site.siteName),
        guest: map.strArtistName || undefined,
        time: formatTimeFromDatetime(map.dtmStartDatetime),
        venue: map.strVenue || site.branchName,
        offer: map.strEntry || undefined,
        image: image.src,
        imageAlt: `${master.eventName} event at ${site.siteName}`,
        imageWidth: image.width,
        imageHeight: image.height,
        features: []
    };
}
function EventsSchedule() {
    const site = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$providers$2f$SiteConfigProvider$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useSiteConfig"])();
    const searchParams = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useSearchParams"])();
    const bookingContext = {
        companyId: searchParams.get("companyId") || site.companyId,
        branchId: searchParams.get("branchId") || site.branchId,
        sessionId: searchParams.get("sessionId") || searchParams.get("tableSessionId") || "",
        tableId: searchParams.get("tableId") || ""
    };
    const requestKey = `${bookingContext.companyId}:${bookingContext.branchId}`;
    const [eventResponse, setEventResponse] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])({
        key: "",
        items: [],
        error: null
    });
    const loading = eventResponse.key !== requestKey;
    const items = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useMemo"])(()=>loading ? [] : eventResponse.items, [
        eventResponse.items,
        loading
    ]);
    const status = loading ? "loading" : eventResponse.error ? "fallback" : "ready";
    const today = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useMemo"])(()=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$site$2d$config$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["getTodayInTimezone"])(site.timezone), [
        site.timezone
    ]);
    const appUrl = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$site$2d$config$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["getDomainUrl"])(site, "APP");
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useEffect"])(()=>{
        const controller = new AbortController();
        const params = new URLSearchParams({
            companyId: bookingContext.companyId,
            branchId: bookingContext.branchId
        });
        fetch(`${API_BASE}/Event/GetEvents?${params}`, {
            headers: {
                Accept: "application/json"
            },
            signal: controller.signal
        }).then((response)=>{
            if (!response.ok) throw new Error(`Events API returned ${response.status}.`);
            return response.json();
        }).then((payload)=>{
            let records;
            if (Array.isArray(payload)) {
                records = payload;
            } else if (typeof payload === "object" && payload !== null && "data" in payload && Array.isArray(payload.data)) {
                records = payload.data;
            } else if (typeof payload === "object" && payload !== null && "items" in payload && Array.isArray(payload.items)) {
                records = payload.items;
            } else {
                throw new Error("Events API returned an unsupported response format.");
            }
            const mapped = [];
            for (const master of records){
                if (!master.masterIsActive) continue;
                const schedules = (master.events || []).filter((event)=>event.mapIsActive);
                for (const schedule of schedules){
                    mapped.push(mapApiToEventItem(master, schedule, site));
                }
            }
            setEventResponse({
                key: requestKey,
                items: mapped,
                error: null
            });
        }).catch((reason)=>{
            if (reason instanceof DOMException && reason.name === "AbortError") return;
            const error = reason instanceof Error ? reason : new Error(String(reason));
            console.error("Events API unavailable.", error);
            setEventResponse({
                key: requestKey,
                items: [],
                error
            });
        });
        return ()=>controller.abort();
    }, [
        bookingContext.branchId,
        bookingContext.companyId,
        requestKey,
        site
    ]);
    const events = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useMemo"])(()=>{
        const withStatus = items.map((item)=>({
                item,
                status: getStatus(item.start, item.end, today)
            }));
        return withStatus.sort((a, b)=>{
            const byStatus = statusRank(a.status) - statusRank(b.status);
            if (byStatus !== 0) return byStatus;
            if (a.status === "past") return b.item.start.localeCompare(a.item.start);
            const byStart = a.item.start.localeCompare(b.item.start);
            if (byStart !== 0) return byStart;
            return a.item.category.localeCompare(b.item.category);
        });
    }, [
        items,
        today
    ]);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("section", {
        className: "sports-schedule",
        id: "events-schedule",
        "aria-labelledby": "events-schedule-heading",
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "home-container",
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "sports-schedule__intro",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                            className: "home-kicker home-kicker--line-right",
                            children: [
                                "Event Calendar",
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                    className: "home-kicker__line",
                                    "aria-hidden": "true"
                                }, void 0, false, {
                                    fileName: "[project]/src/components/events/EventsSchedule.tsx",
                                    lineNumber: 219,
                                    columnNumber: 13
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/src/components/events/EventsSchedule.tsx",
                            lineNumber: 217,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                            id: "events-schedule-heading",
                            className: "home-heading home-heading--split",
                            children: [
                                "Live, Upcoming & ",
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                    className: "text-gold",
                                    children: "Past"
                                }, void 0, false, {
                                    fileName: "[project]/src/components/events/EventsSchedule.tsx",
                                    lineNumber: 222,
                                    columnNumber: 34
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/src/components/events/EventsSchedule.tsx",
                            lineNumber: 221,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "home-divider",
                            "aria-hidden": "true"
                        }, void 0, false, {
                            fileName: "[project]/src/components/events/EventsSchedule.tsx",
                            lineNumber: 224,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                            className: "home-copy sports-schedule__copy",
                            children: "Browse current nights and previous performances at the lounge. Times may update closer to the event date."
                        }, void 0, false, {
                            fileName: "[project]/src/components/events/EventsSchedule.tsx",
                            lineNumber: 225,
                            columnNumber: 11
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/components/events/EventsSchedule.tsx",
                    lineNumber: 216,
                    columnNumber: 9
                }, this),
                status === "fallback" && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                    role: "status",
                    className: "home-copy",
                    style: {
                        marginTop: "1rem",
                        color: "#b8860b"
                    },
                    children: "Live event schedule unavailable. Please try again later."
                }, void 0, false, {
                    fileName: "[project]/src/components/events/EventsSchedule.tsx",
                    lineNumber: 231,
                    columnNumber: 11
                }, this),
                status === "loading" ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                    className: "sports-empty",
                    role: "status",
                    children: "Loading events…"
                }, void 0, false, {
                    fileName: "[project]/src/components/events/EventsSchedule.tsx",
                    lineNumber: 236,
                    columnNumber: 11
                }, this) : events.length === 0 ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                    className: "sports-empty",
                    children: "No events scheduled right now. Please check back shortly."
                }, void 0, false, {
                    fileName: "[project]/src/components/events/EventsSchedule.tsx",
                    lineNumber: 238,
                    columnNumber: 11
                }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "event-cards",
                    "aria-live": "polite",
                    children: events.map(({ item, status })=>{
                        const isPast = status === "past";
                        const badgeLabel = status === "live" ? "Live" : isPast ? "Past" : "Upcoming";
                        const eventDetails = {
                            id: `${item.category}-${item.start}`,
                            name: item.title,
                            guest: item.guest || "",
                            dateStart: item.start,
                            dateEnd: item.end,
                            time: item.time,
                            venue: item.venue,
                            offer: item.offer || "",
                            description: item.description
                        };
                        const eventParams = new URLSearchParams({
                            companyId: bookingContext.companyId,
                            branchId: bookingContext.branchId,
                            ...bookingContext.sessionId ? {
                                sessionId: bookingContext.sessionId
                            } : {},
                            ...bookingContext.tableId ? {
                                tableId: bookingContext.tableId
                            } : {},
                            categoryName: "Events",
                            category: "EVENT",
                            reservationCategory: "EVENT",
                            eventName: item.title,
                            bookingType: "Event",
                            sessionType: "Event",
                            reservationTitle: item.title,
                            dateStart: item.start,
                            uaeTime: item.time,
                            extraDetails: JSON.stringify(eventDetails),
                            step: "about-you",
                            hideSteps: "true",
                            hideCardIcon: "true"
                        });
                        const checkoutHref = appUrl ? `${appUrl}/checkout?${eventParams.toString()}` : "";
                        return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("article", {
                            className: `event-card${isPast ? " event-card--past" : ""}`,
                            children: [
                                item.image && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "event-card__media",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                            className: `event-card__badge event-card__badge--${status}`,
                                            children: badgeLabel
                                        }, void 0, false, {
                                            fileName: "[project]/src/components/events/EventsSchedule.tsx",
                                            lineNumber: 279,
                                            columnNumber: 23
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("img", {
                                            src: item.image,
                                            alt: item.imageAlt || item.title,
                                            width: item.imageWidth || 1024,
                                            height: item.imageHeight || 1024,
                                            loading: "lazy",
                                            style: {
                                                objectFit: "cover",
                                                width: "100%",
                                                height: "100%"
                                            }
                                        }, void 0, false, {
                                            fileName: "[project]/src/components/events/EventsSchedule.tsx",
                                            lineNumber: 281,
                                            columnNumber: 23
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/src/components/events/EventsSchedule.tsx",
                                    lineNumber: 278,
                                    columnNumber: 21
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "event-card__body",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                                            className: "event-card__title",
                                            children: item.title
                                        }, void 0, false, {
                                            fileName: "[project]/src/components/events/EventsSchedule.tsx",
                                            lineNumber: 292,
                                            columnNumber: 21
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("ul", {
                                            className: "event-card__meta",
                                            children: [
                                                item.guest && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("li", {
                                                    children: [
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
                                                            viewBox: "0 0 24 24",
                                                            fill: "none",
                                                            stroke: "currentColor",
                                                            strokeWidth: "1.8",
                                                            "aria-hidden": "true",
                                                            children: [
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                                                                    d: "M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2"
                                                                }, void 0, false, {
                                                                    fileName: "[project]/src/components/events/EventsSchedule.tsx",
                                                                    lineNumber: 297,
                                                                    columnNumber: 29
                                                                }, this),
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("circle", {
                                                                    cx: "9",
                                                                    cy: "7",
                                                                    r: "4"
                                                                }, void 0, false, {
                                                                    fileName: "[project]/src/components/events/EventsSchedule.tsx",
                                                                    lineNumber: 298,
                                                                    columnNumber: 29
                                                                }, this),
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                                                                    d: "M22 21v-2a4 4 0 0 0-3-3.87M16 3.13a4 4 0 0 1 0 7.75"
                                                                }, void 0, false, {
                                                                    fileName: "[project]/src/components/events/EventsSchedule.tsx",
                                                                    lineNumber: 299,
                                                                    columnNumber: 29
                                                                }, this)
                                                            ]
                                                        }, void 0, true, {
                                                            fileName: "[project]/src/components/events/EventsSchedule.tsx",
                                                            lineNumber: 296,
                                                            columnNumber: 27
                                                        }, this),
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                            children: [
                                                                "Artist: ",
                                                                item.guest
                                                            ]
                                                        }, void 0, true, {
                                                            fileName: "[project]/src/components/events/EventsSchedule.tsx",
                                                            lineNumber: 301,
                                                            columnNumber: 27
                                                        }, this)
                                                    ]
                                                }, void 0, true, {
                                                    fileName: "[project]/src/components/events/EventsSchedule.tsx",
                                                    lineNumber: 295,
                                                    columnNumber: 25
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("li", {
                                                    children: [
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
                                                            viewBox: "0 0 24 24",
                                                            fill: "none",
                                                            stroke: "currentColor",
                                                            strokeWidth: "1.8",
                                                            "aria-hidden": "true",
                                                            children: [
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("rect", {
                                                                    x: "3",
                                                                    y: "4",
                                                                    width: "18",
                                                                    height: "18",
                                                                    rx: "2"
                                                                }, void 0, false, {
                                                                    fileName: "[project]/src/components/events/EventsSchedule.tsx",
                                                                    lineNumber: 306,
                                                                    columnNumber: 27
                                                                }, this),
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                                                                    d: "M16 2v4M8 2v4M3 10h18"
                                                                }, void 0, false, {
                                                                    fileName: "[project]/src/components/events/EventsSchedule.tsx",
                                                                    lineNumber: 307,
                                                                    columnNumber: 27
                                                                }, this)
                                                            ]
                                                        }, void 0, true, {
                                                            fileName: "[project]/src/components/events/EventsSchedule.tsx",
                                                            lineNumber: 305,
                                                            columnNumber: 25
                                                        }, this),
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                            children: [
                                                                "Date: ",
                                                                formatDisplayDate(item.start)
                                                            ]
                                                        }, void 0, true, {
                                                            fileName: "[project]/src/components/events/EventsSchedule.tsx",
                                                            lineNumber: 309,
                                                            columnNumber: 25
                                                        }, this)
                                                    ]
                                                }, void 0, true, {
                                                    fileName: "[project]/src/components/events/EventsSchedule.tsx",
                                                    lineNumber: 304,
                                                    columnNumber: 23
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("li", {
                                                    children: [
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
                                                            viewBox: "0 0 24 24",
                                                            fill: "none",
                                                            stroke: "currentColor",
                                                            strokeWidth: "1.8",
                                                            "aria-hidden": "true",
                                                            children: [
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("circle", {
                                                                    cx: "12",
                                                                    cy: "12",
                                                                    r: "9"
                                                                }, void 0, false, {
                                                                    fileName: "[project]/src/components/events/EventsSchedule.tsx",
                                                                    lineNumber: 313,
                                                                    columnNumber: 27
                                                                }, this),
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                                                                    d: "M12 7v5l3 2"
                                                                }, void 0, false, {
                                                                    fileName: "[project]/src/components/events/EventsSchedule.tsx",
                                                                    lineNumber: 314,
                                                                    columnNumber: 27
                                                                }, this)
                                                            ]
                                                        }, void 0, true, {
                                                            fileName: "[project]/src/components/events/EventsSchedule.tsx",
                                                            lineNumber: 312,
                                                            columnNumber: 25
                                                        }, this),
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                            children: [
                                                                "Time: ",
                                                                item.time
                                                            ]
                                                        }, void 0, true, {
                                                            fileName: "[project]/src/components/events/EventsSchedule.tsx",
                                                            lineNumber: 316,
                                                            columnNumber: 25
                                                        }, this)
                                                    ]
                                                }, void 0, true, {
                                                    fileName: "[project]/src/components/events/EventsSchedule.tsx",
                                                    lineNumber: 311,
                                                    columnNumber: 23
                                                }, this),
                                                item.offer && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("li", {
                                                    children: [
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
                                                            viewBox: "0 0 24 24",
                                                            fill: "none",
                                                            stroke: "currentColor",
                                                            strokeWidth: "1.8",
                                                            "aria-hidden": "true",
                                                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                                                                d: "M12 2l2.5 7h7l-5.5 4.2 2.1 6.8L12 16.5 5.9 20l2.1-6.8L2.5 9h7L12 2z"
                                                            }, void 0, false, {
                                                                fileName: "[project]/src/components/events/EventsSchedule.tsx",
                                                                lineNumber: 321,
                                                                columnNumber: 29
                                                            }, this)
                                                        }, void 0, false, {
                                                            fileName: "[project]/src/components/events/EventsSchedule.tsx",
                                                            lineNumber: 320,
                                                            columnNumber: 27
                                                        }, this),
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                            children: [
                                                                "Entry: ",
                                                                /free/i.test(item.offer) ? "Free" : item.offer
                                                            ]
                                                        }, void 0, true, {
                                                            fileName: "[project]/src/components/events/EventsSchedule.tsx",
                                                            lineNumber: 323,
                                                            columnNumber: 27
                                                        }, this)
                                                    ]
                                                }, void 0, true, {
                                                    fileName: "[project]/src/components/events/EventsSchedule.tsx",
                                                    lineNumber: 319,
                                                    columnNumber: 25
                                                }, this)
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/src/components/events/EventsSchedule.tsx",
                                            lineNumber: 293,
                                            columnNumber: 21
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "event-card__actions",
                                            children: isPast ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                className: "event-card__btn event-card__btn--ended",
                                                children: "Event Ended"
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/events/EventsSchedule.tsx",
                                                lineNumber: 329,
                                                columnNumber: 25
                                            }, this) : appUrl ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("a", {
                                                href: checkoutHref,
                                                className: "event-card__btn event-card__btn--solid",
                                                children: "Book Event"
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/events/EventsSchedule.tsx",
                                                lineNumber: 331,
                                                columnNumber: 25
                                            }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                className: "event-card__btn event-card__btn--ended",
                                                children: "Booking unavailable"
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/events/EventsSchedule.tsx",
                                                lineNumber: 335,
                                                columnNumber: 25
                                            }, this)
                                        }, void 0, false, {
                                            fileName: "[project]/src/components/events/EventsSchedule.tsx",
                                            lineNumber: 327,
                                            columnNumber: 21
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/src/components/events/EventsSchedule.tsx",
                                    lineNumber: 291,
                                    columnNumber: 19
                                }, this)
                            ]
                        }, item.title + item.start, true, {
                            fileName: "[project]/src/components/events/EventsSchedule.tsx",
                            lineNumber: 276,
                            columnNumber: 17
                        }, this);
                    })
                }, void 0, false, {
                    fileName: "[project]/src/components/events/EventsSchedule.tsx",
                    lineNumber: 240,
                    columnNumber: 11
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/events/EventsSchedule.tsx",
            lineNumber: 215,
            columnNumber: 7
        }, this)
    }, void 0, false, {
        fileName: "[project]/src/components/events/EventsSchedule.tsx",
        lineNumber: 214,
        columnNumber: 5
    }, this);
}
}),
];

//# sourceMappingURL=src_components_03v86c3._.js.map