module.exports = [
"[project]/src/components/common/HeroAnimate.tsx [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "HeroAnimate",
    ()=>HeroAnimate
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react.js [app-ssr] (ecmascript)");
"use client";
;
;
function HeroAnimate({ children, className, bgSelector }) {
    const ref = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useRef"])(null);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useEffect"])(()=>{
        const root = ref.current;
        if (!root) return;
        const reduced = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
        const items = Array.from(root.querySelectorAll(".hero-anim"));
        if (reduced) {
            items.forEach((el)=>{
                el.style.opacity = "1";
            });
            return;
        }
        if (bgSelector) {
            const bg = root.querySelector(bgSelector);
            if (bg) {
                bg.animate([
                    {
                        transform: "scale(1.08)"
                    },
                    {
                        transform: "scale(1)"
                    }
                ], {
                    duration: 2200,
                    easing: "cubic-bezier(0.16,1,0.3,1)",
                    fill: "forwards"
                });
            }
        }
        items.forEach((el, i)=>{
            el.animate([
                {
                    opacity: 0,
                    transform: "translateY(28px)"
                },
                {
                    opacity: 1,
                    transform: "translateY(0)"
                }
            ], {
                duration: 900,
                delay: 250 + i * 130,
                easing: "cubic-bezier(0.22,1,0.36,1)",
                fill: "forwards"
            });
        });
    }, [
        bgSelector
    ]);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        ref: ref,
        className: className,
        children: children
    }, void 0, false, {
        fileName: "[project]/src/components/common/HeroAnimate.tsx",
        lineNumber: 57,
        columnNumber: 5
    }, this);
}
}),
"[project]/src/components/live-sports/SportsSchedule.tsx [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "SportsSchedule",
    ()=>SportsSchedule
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/navigation.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$data$2f$sports$2d$schedule$2e$json$2e5b$json$5d2e$cjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/data/sports-schedule.json.[json].cjs [app-ssr] (ecmascript)");
"use client";
;
;
;
;
const MONTH_ORDER = [
    "january",
    "february",
    "march",
    "april",
    "may",
    "june",
    "july",
    "august",
    "september",
    "october",
    "november",
    "december"
];
function parseLocalDate(iso) {
    const [y, m, d] = iso.split("-").map(Number);
    return new Date(y, m - 1, d);
}
function formatDisplayDate(iso) {
    const date = parseLocalDate(iso);
    const dd = String(date.getDate()).padStart(2, "0");
    const mon = date.toLocaleString("en-GB", {
        month: "short"
    });
    return `${dd}-${mon}-${date.getFullYear()}`;
}
function formatDateRange(start, end) {
    if (start === end) return formatDisplayDate(start);
    return `${formatDisplayDate(start)} \u2013 ${formatDisplayDate(end)}`;
}
function getStatus(start, end, today) {
    const s = parseLocalDate(start);
    const e = parseLocalDate(end);
    e.setHours(23, 59, 59, 999);
    s.setHours(0, 0, 0, 0);
    if (today > e) return "past";
    if (today >= s && today <= e) return "live";
    return "upcoming";
}
function statusLabel(status) {
    if (status === "live") return "Live";
    if (status === "past") return "Past";
    return "Upcoming";
}
function titleCaseMonth(slug) {
    return slug.charAt(0).toUpperCase() + slug.slice(1);
}
const PAGE_SIZE_OPTIONS = [
    10,
    20,
    50
];
const REMOTE_API_BASE = "https://restaurents-api.cylsys.com";
/** Dev proxy path — see the `rewrites` block in next.config.ts. Avoids CORS on localhost. */ const DEV_API_BASE = "/live-sports-api";
const LIVE_SPORTS_API = "/api/Livesports/GetLiveSports";
const LIVE_SPORTS_COMPETITIONS_API = "/api/Livesports/GetLiveSportsCompetitions";
/**
 * Called from the effect (not at module scope) so `window` is available.
 * Order: NEXT_PUBLIC_LIVE_SPORTS_BASE -> dev proxy on localhost -> remote.
 */ function getApiBase() {
    const configured = process.env.NEXT_PUBLIC_LIVE_SPORTS_BASE;
    if (configured) return configured.replace(/\/$/, "");
    if (("TURBOPACK compile-time value", "undefined") !== "undefined" && /^(localhost|127\.0\.0\.1|\[::1\])$/.test(window.location.hostname)) //TURBOPACK unreachable
    ;
    return REMOTE_API_BASE;
}
const DEFAULT_COMPANY_ID = "0ffbe39e-abf8-4827-9107-1a04b39f3416";
const DEFAULT_BRANCH_ID = "f4fb1d76-83a0-4965-86b5-63da28249dae";
const MENU_CHECKOUT_URL = "https://app.thedesirelounge.com/checkout";
const LIST_KEYS = [
    "data",
    "result",
    "results",
    "items",
    "records",
    "list",
    "response",
    "payload",
    "value"
];
function extractList(payload, depth = 0) {
    if (payload == null || depth > 4) return [];
    if (typeof payload === "string") {
        const text = payload.trim();
        if (!text) return [];
        try {
            return extractList(JSON.parse(text), depth + 1);
        } catch  {
            return [];
        }
    }
    if (Array.isArray(payload)) {
        return payload.filter((item)=>typeof item === "object" && item !== null);
    }
    if (typeof payload === "object") {
        const obj = payload;
        for (const key of Object.keys(obj)){
            if (LIST_KEYS.includes(key.toLowerCase())) {
                const nested = extractList(obj[key], depth + 1);
                if (nested.length) return nested;
            }
        }
        // Fall back to the first array-ish value on the object.
        for (const key of Object.keys(obj)){
            const value = obj[key];
            if (Array.isArray(value)) {
                const nested = extractList(value, depth + 1);
                if (nested.length) return nested;
            }
        }
    }
    return [];
}
/** Case-insensitive field lookup, so PascalCase payloads work too. */ function pick(item, ...names) {
    const keys = Object.keys(item);
    for (const name of names){
        const match = keys.find((key)=>key.toLowerCase() === name.toLowerCase());
        if (match) {
            const value = item[match];
            if (value != null && value !== "") return String(value);
        }
    }
    return "";
}
function toDate(value) {
    if (!value) return "";
    const trimmed = value.trim();
    // "2026-09-15 00:00:00" / "2026-09-15T00:00:00" / "2026-09-15"
    const iso = trimmed.match(/^(\d{4})-(\d{2})-(\d{2})/);
    if (iso) return `${iso[1]}-${iso[2]}-${iso[3]}`;
    // "15/09/2026" or "15-09-2026"
    const dmy = trimmed.match(/^(\d{2})[/-](\d{2})[/-](\d{4})/);
    if (dmy) return `${dmy[3]}-${dmy[2]}-${dmy[1]}`;
    const parsed = new Date(trimmed);
    if (!Number.isNaN(parsed.getTime())) {
        const mm = String(parsed.getMonth() + 1).padStart(2, "0");
        const dd = String(parsed.getDate()).padStart(2, "0");
        return `${parsed.getFullYear()}-${mm}-${dd}`;
    }
    return "";
}
function normalizeLiveFixture(item) {
    const start = toDate(pick(item, "dateStart", "startDate", "date", "eventDate", "matchDate"));
    if (!start) return null;
    const end = toDate(pick(item, "dateEnd", "endDate")) || start;
    const home = pick(item, "teamHome", "homeTeam", "team1");
    const away = pick(item, "teamAway", "awayTeam", "team2");
    const sportValue = pick(item, "sportCategory", "sportCategoryName", "sport", "categoryName").toLowerCase();
    return {
        id: pick(item, "id", "sportId", "liveSportId") || undefined,
        sport: sportValue.includes("football") || sportValue.includes("soccer") ? "football" : "cricket",
        month: new Date(`${start}T12:00:00`).toLocaleString("en-US", {
            month: "long"
        }).toLowerCase(),
        start,
        end: end >= start ? end : start,
        competition: pick(item, "competitionName", "competition", "tournamentName") || "Competition TBC",
        event: pick(item, "eventName", "event", "name", "matchName") || "Upcoming fixture",
        teams: `${home || "TBC"} vs ${away || "TBC"}`,
        venue: pick(item, "venue", "venueName", "location") || "Venue TBC",
        time: pick(item, "uaeTime", "time", "matchTime", "startTime") || "TBC",
        channel: pick(item, "channel", "channelName", "broadcast") || "Channel TBC"
    };
}
function normalizeCompetition(item) {
    return pick(item, "name", "competitionName", "title");
}
function buildBookingUrl(item, context) {
    const details = {
        id: item.id || "",
        name: item.event,
        sportCategory: item.sport,
        competitionName: item.competition,
        teamHome: item.teams.split(" vs ")[0] || "",
        teamAway: item.teams.split(" vs ")[1] || "",
        venue: item.venue,
        dateStart: item.start,
        uaeTime: item.time,
        channel: item.channel
    };
    const params = new URLSearchParams({
        companyId: context.companyId,
        branchId: context.branchId,
        ...context.sessionId ? {
            sessionId: context.sessionId
        } : {},
        ...context.tableId ? {
            tableId: context.tableId
        } : {},
        categoryName: "Live Sports",
        category: "EVENT",
        reservationCategory: "EVENT",
        sessionType: "Live Sports",
        eventName: item.event,
        competitionName: item.competition,
        sportCategory: item.sport,
        teamHome: details.teamHome,
        teamAway: details.teamAway,
        venue: item.venue,
        dateStart: item.start,
        uaeTime: item.time,
        channel: item.channel,
        reservationTitle: item.event,
        extraDetails: JSON.stringify(details),
        step: "about-you",
        hideSteps: "true",
        hideCardIcon: "true",
        hideCurrentSession: "true",
        showCurrentTable: "false"
    });
    return `${MENU_CHECKOUT_URL}?${params.toString()}`;
}
function isAbort(error) {
    return error instanceof DOMException && error.name === "AbortError";
}
/**
 * POST first (current API contract); if that is rejected, retry the same
 * endpoint as GET. Never throws for network/CORS failures — it returns null so
 * the UI can fall back to the bundled schedule instead of crashing the page.
 */ async function requestJson(path, body, signal) {
    const url = `${getApiBase()}${path}`;
    try {
        const response = await fetch(url, {
            method: "POST",
            headers: {
                "Content-Type": "application/json",
                Accept: "application/json"
            },
            body: JSON.stringify(body),
            signal
        });
        if (response.ok) return await response.json();
        console.warn(`Live sports POST ${url} -> ${response.status}; retrying as GET`);
    } catch (error) {
        if (isAbort(error)) throw error;
        console.warn(`Live sports POST ${url} failed (network/CORS); retrying as GET`, error);
    }
    try {
        const query = new URLSearchParams(body).toString();
        const response = await fetch(`${url}?${query}`, {
            method: "GET",
            headers: {
                Accept: "application/json"
            },
            signal
        });
        if (response.ok) return await response.json();
        console.warn(`Live sports GET ${url} -> ${response.status}`);
    } catch (error) {
        if (isAbort(error)) throw error;
        console.warn(`Live sports GET ${url} failed (network/CORS)`, error);
    }
    return null;
}
const LOCAL_FIXTURES = __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$data$2f$sports$2d$schedule$2e$json$2e5b$json$5d2e$cjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"].fixtures.map((item)=>({
        ...item,
        month: item.month.toLowerCase()
    }));
function SportsSchedule() {
    const searchParams = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useSearchParams"])();
    const companyId = searchParams.get("companyId") || DEFAULT_COMPANY_ID;
    const branchId = searchParams.get("branchId") || DEFAULT_BRANCH_ID;
    const sessionId = searchParams.get("sessionId") || searchParams.get("tableSessionId") || "";
    const tableId = searchParams.get("tableId") || "";
    const bookingContext = {
        companyId,
        branchId,
        sessionId,
        tableId
    };
    const [apiFixtures, setApiFixtures] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(null);
    const [apiCompetitions, setApiCompetitions] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])([]);
    const [loading, setLoading] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(true);
    const [loadError, setLoadError] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(false);
    const [reloadKey, setReloadKey] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(0);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useEffect"])(()=>{
        const controller = new AbortController();
        let active = true;
        setLoading(true);
        setLoadError(false);
        // Competitions are optional — a failure there must not blank the fixtures.
        requestJson(LIVE_SPORTS_COMPETITIONS_API, {
            companyId,
            branchId
        }, controller.signal).then((payload)=>{
            if (!active) return;
            const names = extractList(payload).map(normalizeCompetition).filter(Boolean);
            setApiCompetitions(names);
        }).catch(()=>{
        /* competition dropdown falls back to the competitions found in fixtures */ });
        requestJson(LIVE_SPORTS_API, {
            companyId,
            branchId,
            statusFilter: "upcoming"
        }, controller.signal).then((payload)=>{
            if (!active) return;
            const fixtures = extractList(payload).map(normalizeLiveFixture).filter((item)=>item !== null);
            // payload === null means the request could not be made at all (CORS/offline).
            setLoadError(payload === null);
            // An empty API list should not wipe the page — keep the bundled list.
            setApiFixtures(fixtures.length ? fixtures : null);
            setLoading(false);
        }).catch((error)=>{
            if (!active) return;
            if (isAbort(error)) return;
            console.error("Live sports API unavailable; using bundled fixtures", error);
            setApiFixtures(null);
            setLoadError(true);
            setLoading(false);
        });
        return ()=>{
            active = false;
            controller.abort();
        };
    }, [
        companyId,
        branchId,
        reloadKey
    ]);
    const retry = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useCallback"])(()=>setReloadKey((n)=>n + 1), []);
    const today = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useMemo"])(()=>{
        const d = new Date();
        d.setHours(12, 0, 0, 0);
        return d;
    }, []);
    const enriched = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useMemo"])(()=>{
        const fixtures = (apiFixtures || LOCAL_FIXTURES).slice().sort((a, b)=>{
            const byStart = a.start.localeCompare(b.start);
            return byStart !== 0 ? byStart : a.sport.localeCompare(b.sport);
        });
        return fixtures.map((item)=>({
                ...item,
                status: getStatus(item.start, item.end, today)
            }));
    }, [
        apiFixtures,
        today
    ]);
    const competitions = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useMemo"])(()=>{
        const fromFixtures = enriched.map((item)=>item.competition);
        const source = apiCompetitions.length ? [
            ...apiCompetitions,
            ...fromFixtures
        ] : fromFixtures;
        return Array.from(new Set(source.filter(Boolean))).sort((a, b)=>a.localeCompare(b));
    }, [
        apiCompetitions,
        enriched
    ]);
    const monthsPresent = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useMemo"])(()=>Array.from(new Set(enriched.map((item)=>item.month.toLowerCase()))).sort((a, b)=>MONTH_ORDER.indexOf(a) - MONTH_ORDER.indexOf(b)), [
        enriched
    ]);
    const [sport, setSport] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])("all");
    const [month, setMonth] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])("all");
    const [status, setStatus] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])("active");
    const [competition, setCompetition] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])("all");
    const [query, setQuery] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])("");
    const [page, setPage] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(1);
    const [pageSize, setPageSize] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(20);
    // If the selected competition/month is not in the freshly loaded data, reset it
    // instead of showing an empty grid.
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useEffect"])(()=>{
        if (competition !== "all" && !competitions.includes(competition)) setCompetition("all");
    }, [
        competitions,
        competition
    ]);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useEffect"])(()=>{
        if (month !== "all" && !monthsPresent.includes(month)) setMonth("all");
    }, [
        monthsPresent,
        month
    ]);
    const filtered = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useMemo"])(()=>{
        const q = query.trim().toLowerCase();
        return enriched.filter((item)=>{
            if (sport !== "all" && item.sport !== sport) return false;
            if (month !== "all" && item.month.toLowerCase() !== month) return false;
            if (competition !== "all" && item.competition !== competition) return false;
            if (status === "active" && item.status === "past") return false;
            if (status === "live" && item.status !== "live") return false;
            if (status === "upcoming" && item.status !== "upcoming") return false;
            if (q) {
                const haystack = [
                    item.competition,
                    item.event,
                    item.teams,
                    item.venue,
                    item.channel,
                    item.sport
                ].join(" ").toLowerCase();
                if (!haystack.includes(q)) return false;
            }
            return true;
        });
    }, [
        enriched,
        sport,
        month,
        competition,
        status,
        query
    ]);
    const totalPages = Math.max(1, Math.ceil(filtered.length / pageSize));
    const currentPage = Math.min(page, totalPages);
    const startIdx = filtered.length ? (currentPage - 1) * pageSize : 0;
    const endIdx = Math.min(startIdx + pageSize, filtered.length);
    const pageItems = filtered.slice(startIdx, endIdx);
    const filtersActive = sport !== "all" || month !== "all" || status !== "active" || competition !== "all" || Boolean(query);
    function resetFilters() {
        setSport("all");
        setMonth("all");
        setStatus("active");
        setCompetition("all");
        setQuery("");
        setPage(1);
    }
    function changePage(p) {
        setPage(Math.min(Math.max(1, p), totalPages));
    }
    const pageButtons = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useMemo"])(()=>{
        if (totalPages <= 1) return [];
        const pages = new Set([
            1,
            totalPages,
            currentPage - 1,
            currentPage,
            currentPage + 1
        ]);
        const sorted = Array.from(pages).filter((p)=>p >= 1 && p <= totalPages).sort((a, b)=>a - b);
        const out = [];
        let last = 0;
        for (const p of sorted){
            if (last && p - last > 1) out.push("gap");
            out.push(p);
            last = p;
        }
        return out;
    }, [
        totalPages,
        currentPage
    ]);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("section", {
        className: "sports-schedule",
        id: "sports-schedule",
        "aria-labelledby": "sports-schedule-heading",
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "home-container",
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "sports-schedule__intro",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                            className: "home-kicker home-kicker--line-right",
                            children: [
                                "Fixture Calendar",
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                    className: "home-kicker__line",
                                    "aria-hidden": "true"
                                }, void 0, false, {
                                    fileName: "[project]/src/components/live-sports/SportsSchedule.tsx",
                                    lineNumber: 464,
                                    columnNumber: 13
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/src/components/live-sports/SportsSchedule.tsx",
                            lineNumber: 462,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                            id: "sports-schedule-heading",
                            className: "home-heading home-heading--split",
                            children: [
                                "Live & ",
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                    className: "text-gold",
                                    children: "Upcoming"
                                }, void 0, false, {
                                    fileName: "[project]/src/components/live-sports/SportsSchedule.tsx",
                                    lineNumber: 467,
                                    columnNumber: 24
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/src/components/live-sports/SportsSchedule.tsx",
                            lineNumber: 466,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "home-divider",
                            "aria-hidden": "true"
                        }, void 0, false, {
                            fileName: "[project]/src/components/live-sports/SportsSchedule.tsx",
                            lineNumber: 469,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                            className: "home-copy sports-schedule__copy",
                            children: "Browse football and cricket fixtures screening at the lounge. Times are UAE-oriented where listed; kick-off and broadcast details may update closer to match day."
                        }, void 0, false, {
                            fileName: "[project]/src/components/live-sports/SportsSchedule.tsx",
                            lineNumber: 470,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                            className: "sports-schedule__count",
                            "aria-live": "polite",
                            children: loading ? "Loading fixtures…" : `${filtered.length} fixture${filtered.length === 1 ? "" : "s"}`
                        }, void 0, false, {
                            fileName: "[project]/src/components/live-sports/SportsSchedule.tsx",
                            lineNumber: 474,
                            columnNumber: 11
                        }, this),
                        loadError && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                            className: "sports-schedule__count",
                            role: "status",
                            children: [
                                "Live feed unavailable right now — showing our latest saved schedule.",
                                " ",
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                    type: "button",
                                    className: "sports-toolbar__reset",
                                    onClick: retry,
                                    children: "Retry"
                                }, void 0, false, {
                                    fileName: "[project]/src/components/live-sports/SportsSchedule.tsx",
                                    lineNumber: 480,
                                    columnNumber: 15
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/src/components/live-sports/SportsSchedule.tsx",
                            lineNumber: 478,
                            columnNumber: 13
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/components/live-sports/SportsSchedule.tsx",
                    lineNumber: 461,
                    columnNumber: 9
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "sports-filters",
                    role: "search",
                    "aria-label": "Filter fixtures",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "sports-filters__row sports-filters__row--controls",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                    className: "sports-search",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                            className: "sports-filters__label",
                                            children: "Search"
                                        }, void 0, false, {
                                            fileName: "[project]/src/components/live-sports/SportsSchedule.tsx",
                                            lineNumber: 490,
                                            columnNumber: 15
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                            className: "sports-search__field",
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
                                                    className: "sports-search__icon",
                                                    width: "16",
                                                    height: "16",
                                                    viewBox: "0 0 24 24",
                                                    fill: "none",
                                                    stroke: "currentColor",
                                                    strokeWidth: "2",
                                                    "aria-hidden": "true",
                                                    children: [
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("circle", {
                                                            cx: "11",
                                                            cy: "11",
                                                            r: "7"
                                                        }, void 0, false, {
                                                            fileName: "[project]/src/components/live-sports/SportsSchedule.tsx",
                                                            lineNumber: 493,
                                                            columnNumber: 19
                                                        }, this),
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                                                            d: "M20 20l-3.5-3.5"
                                                        }, void 0, false, {
                                                            fileName: "[project]/src/components/live-sports/SportsSchedule.tsx",
                                                            lineNumber: 494,
                                                            columnNumber: 19
                                                        }, this)
                                                    ]
                                                }, void 0, true, {
                                                    fileName: "[project]/src/components/live-sports/SportsSchedule.tsx",
                                                    lineNumber: 492,
                                                    columnNumber: 17
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                                    type: "search",
                                                    className: "sports-search__input",
                                                    placeholder: "Teams, competition, venue…",
                                                    autoComplete: "off",
                                                    value: query,
                                                    onChange: (e)=>{
                                                        setQuery(e.target.value);
                                                        setPage(1);
                                                    }
                                                }, void 0, false, {
                                                    fileName: "[project]/src/components/live-sports/SportsSchedule.tsx",
                                                    lineNumber: 496,
                                                    columnNumber: 17
                                                }, this)
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/src/components/live-sports/SportsSchedule.tsx",
                                            lineNumber: 491,
                                            columnNumber: 15
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/src/components/live-sports/SportsSchedule.tsx",
                                    lineNumber: 489,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                    className: "sports-select",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                            className: "sports-filters__label",
                                            children: "Competition"
                                        }, void 0, false, {
                                            fileName: "[project]/src/components/live-sports/SportsSchedule.tsx",
                                            lineNumber: 511,
                                            columnNumber: 15
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("select", {
                                            className: "sports-select__control",
                                            value: competition,
                                            onChange: (e)=>{
                                                setCompetition(e.target.value);
                                                setPage(1);
                                            },
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                                    value: "all",
                                                    children: "All competitions"
                                                }, void 0, false, {
                                                    fileName: "[project]/src/components/live-sports/SportsSchedule.tsx",
                                                    lineNumber: 520,
                                                    columnNumber: 17
                                                }, this),
                                                competitions.map((c)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                                        value: c,
                                                        children: c
                                                    }, c, false, {
                                                        fileName: "[project]/src/components/live-sports/SportsSchedule.tsx",
                                                        lineNumber: 522,
                                                        columnNumber: 19
                                                    }, this))
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/src/components/live-sports/SportsSchedule.tsx",
                                            lineNumber: 512,
                                            columnNumber: 15
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/src/components/live-sports/SportsSchedule.tsx",
                                    lineNumber: 510,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                    className: "sports-select",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                            className: "sports-filters__label",
                                            children: "Per page"
                                        }, void 0, false, {
                                            fileName: "[project]/src/components/live-sports/SportsSchedule.tsx",
                                            lineNumber: 530,
                                            columnNumber: 15
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("select", {
                                            className: "sports-select__control",
                                            value: pageSize,
                                            onChange: (e)=>{
                                                setPageSize(Number(e.target.value));
                                                setPage(1);
                                            },
                                            children: PAGE_SIZE_OPTIONS.map((n)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                                    value: n,
                                                    children: n
                                                }, n, false, {
                                                    fileName: "[project]/src/components/live-sports/SportsSchedule.tsx",
                                                    lineNumber: 540,
                                                    columnNumber: 19
                                                }, this))
                                        }, void 0, false, {
                                            fileName: "[project]/src/components/live-sports/SportsSchedule.tsx",
                                            lineNumber: 531,
                                            columnNumber: 15
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/src/components/live-sports/SportsSchedule.tsx",
                                    lineNumber: 529,
                                    columnNumber: 13
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/src/components/live-sports/SportsSchedule.tsx",
                            lineNumber: 488,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "sports-filters__group",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                    className: "sports-filters__label",
                                    children: "Sport"
                                }, void 0, false, {
                                    fileName: "[project]/src/components/live-sports/SportsSchedule.tsx",
                                    lineNumber: 549,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "gallery-filters",
                                    role: "tablist",
                                    children: [
                                        "all",
                                        "football",
                                        "cricket"
                                    ].map((s)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                            type: "button",
                                            className: `gallery-filters__btn${sport === s ? " is-active" : ""}`,
                                            onClick: ()=>{
                                                setSport(s);
                                                setPage(1);
                                            },
                                            children: s === "all" ? "All" : s.charAt(0).toUpperCase() + s.slice(1)
                                        }, s, false, {
                                            fileName: "[project]/src/components/live-sports/SportsSchedule.tsx",
                                            lineNumber: 552,
                                            columnNumber: 17
                                        }, this))
                                }, void 0, false, {
                                    fileName: "[project]/src/components/live-sports/SportsSchedule.tsx",
                                    lineNumber: 550,
                                    columnNumber: 13
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/src/components/live-sports/SportsSchedule.tsx",
                            lineNumber: 548,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "sports-filters__group",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                    className: "sports-filters__label",
                                    children: "Status"
                                }, void 0, false, {
                                    fileName: "[project]/src/components/live-sports/SportsSchedule.tsx",
                                    lineNumber: 568,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "gallery-filters",
                                    role: "tablist",
                                    children: [
                                        [
                                            "active",
                                            "Live & Upcoming"
                                        ],
                                        [
                                            "live",
                                            "Live Now"
                                        ],
                                        [
                                            "upcoming",
                                            "Upcoming"
                                        ],
                                        [
                                            "all",
                                            "All Dates"
                                        ]
                                    ].map(([value, label])=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                            type: "button",
                                            className: `gallery-filters__btn${status === value ? " is-active" : ""}`,
                                            onClick: ()=>{
                                                setStatus(value);
                                                setPage(1);
                                            },
                                            children: label
                                        }, value, false, {
                                            fileName: "[project]/src/components/live-sports/SportsSchedule.tsx",
                                            lineNumber: 578,
                                            columnNumber: 17
                                        }, this))
                                }, void 0, false, {
                                    fileName: "[project]/src/components/live-sports/SportsSchedule.tsx",
                                    lineNumber: 569,
                                    columnNumber: 13
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/src/components/live-sports/SportsSchedule.tsx",
                            lineNumber: 567,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "sports-filters__group",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                    className: "sports-filters__label",
                                    children: "Month"
                                }, void 0, false, {
                                    fileName: "[project]/src/components/live-sports/SportsSchedule.tsx",
                                    lineNumber: 594,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "gallery-filters",
                                    role: "tablist",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                            type: "button",
                                            className: `gallery-filters__btn${month === "all" ? " is-active" : ""}`,
                                            onClick: ()=>{
                                                setMonth("all");
                                                setPage(1);
                                            },
                                            children: "All"
                                        }, void 0, false, {
                                            fileName: "[project]/src/components/live-sports/SportsSchedule.tsx",
                                            lineNumber: 596,
                                            columnNumber: 15
                                        }, this),
                                        monthsPresent.map((m)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                type: "button",
                                                className: `gallery-filters__btn${month === m ? " is-active" : ""}`,
                                                onClick: ()=>{
                                                    setMonth(m);
                                                    setPage(1);
                                                },
                                                children: titleCaseMonth(m)
                                            }, m, false, {
                                                fileName: "[project]/src/components/live-sports/SportsSchedule.tsx",
                                                lineNumber: 600,
                                                columnNumber: 17
                                            }, this))
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/src/components/live-sports/SportsSchedule.tsx",
                                    lineNumber: 595,
                                    columnNumber: 13
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/src/components/live-sports/SportsSchedule.tsx",
                            lineNumber: 593,
                            columnNumber: 11
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/components/live-sports/SportsSchedule.tsx",
                    lineNumber: 487,
                    columnNumber: 9
                }, this),
                filtered.length > 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "sports-toolbar",
                    id: "sports-toolbar",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                            className: "sports-toolbar__range",
                            "aria-live": "polite",
                            children: `Showing ${filtered.length ? startIdx + 1 : 0}\u2013${endIdx} of ${filtered.length}`
                        }, void 0, false, {
                            fileName: "[project]/src/components/live-sports/SportsSchedule.tsx",
                            lineNumber: 618,
                            columnNumber: 13
                        }, this),
                        filtersActive && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                            type: "button",
                            className: "sports-toolbar__reset",
                            onClick: resetFilters,
                            children: "Clear filters"
                        }, void 0, false, {
                            fileName: "[project]/src/components/live-sports/SportsSchedule.tsx",
                            lineNumber: 622,
                            columnNumber: 15
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/components/live-sports/SportsSchedule.tsx",
                    lineNumber: 617,
                    columnNumber: 11
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "sports-cards",
                    "aria-live": "polite",
                    children: pageItems.map((item, i)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("article", {
                            className: "sports-card",
                            "data-status": item.status,
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("header", {
                                    className: "sports-card__head",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                            className: `sports-card__sport sports-card__sport--${item.sport}`,
                                            children: item.sport === "football" ? "Football" : "Cricket"
                                        }, void 0, false, {
                                            fileName: "[project]/src/components/live-sports/SportsSchedule.tsx",
                                            lineNumber: 633,
                                            columnNumber: 17
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                            className: `sports-card__status sports-card__status--${item.status}`,
                                            children: statusLabel(item.status)
                                        }, void 0, false, {
                                            fileName: "[project]/src/components/live-sports/SportsSchedule.tsx",
                                            lineNumber: 636,
                                            columnNumber: 17
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/src/components/live-sports/SportsSchedule.tsx",
                                    lineNumber: 632,
                                    columnNumber: 15
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                                    className: "sports-card__title",
                                    children: item.competition
                                }, void 0, false, {
                                    fileName: "[project]/src/components/live-sports/SportsSchedule.tsx",
                                    lineNumber: 638,
                                    columnNumber: 15
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                    className: "sports-card__event",
                                    children: item.event
                                }, void 0, false, {
                                    fileName: "[project]/src/components/live-sports/SportsSchedule.tsx",
                                    lineNumber: 639,
                                    columnNumber: 15
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("dl", {
                                    className: "sports-card__meta",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("dt", {
                                                    children: "Dates"
                                                }, void 0, false, {
                                                    fileName: "[project]/src/components/live-sports/SportsSchedule.tsx",
                                                    lineNumber: 642,
                                                    columnNumber: 19
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("dd", {
                                                    children: formatDateRange(item.start, item.end)
                                                }, void 0, false, {
                                                    fileName: "[project]/src/components/live-sports/SportsSchedule.tsx",
                                                    lineNumber: 643,
                                                    columnNumber: 19
                                                }, this)
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/src/components/live-sports/SportsSchedule.tsx",
                                            lineNumber: 641,
                                            columnNumber: 17
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("dt", {
                                                    children: "Teams"
                                                }, void 0, false, {
                                                    fileName: "[project]/src/components/live-sports/SportsSchedule.tsx",
                                                    lineNumber: 646,
                                                    columnNumber: 19
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("dd", {
                                                    children: item.teams
                                                }, void 0, false, {
                                                    fileName: "[project]/src/components/live-sports/SportsSchedule.tsx",
                                                    lineNumber: 647,
                                                    columnNumber: 19
                                                }, this)
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/src/components/live-sports/SportsSchedule.tsx",
                                            lineNumber: 645,
                                            columnNumber: 17
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("dt", {
                                                    children: "Venue"
                                                }, void 0, false, {
                                                    fileName: "[project]/src/components/live-sports/SportsSchedule.tsx",
                                                    lineNumber: 650,
                                                    columnNumber: 19
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("dd", {
                                                    children: item.venue
                                                }, void 0, false, {
                                                    fileName: "[project]/src/components/live-sports/SportsSchedule.tsx",
                                                    lineNumber: 651,
                                                    columnNumber: 19
                                                }, this)
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/src/components/live-sports/SportsSchedule.tsx",
                                            lineNumber: 649,
                                            columnNumber: 17
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("dt", {
                                                    children: "UAE Time"
                                                }, void 0, false, {
                                                    fileName: "[project]/src/components/live-sports/SportsSchedule.tsx",
                                                    lineNumber: 654,
                                                    columnNumber: 19
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("dd", {
                                                    children: item.time
                                                }, void 0, false, {
                                                    fileName: "[project]/src/components/live-sports/SportsSchedule.tsx",
                                                    lineNumber: 655,
                                                    columnNumber: 19
                                                }, this)
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/src/components/live-sports/SportsSchedule.tsx",
                                            lineNumber: 653,
                                            columnNumber: 17
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "sports-card__meta--wide",
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("dt", {
                                                    children: "Watch on"
                                                }, void 0, false, {
                                                    fileName: "[project]/src/components/live-sports/SportsSchedule.tsx",
                                                    lineNumber: 658,
                                                    columnNumber: 19
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("dd", {
                                                    children: item.channel
                                                }, void 0, false, {
                                                    fileName: "[project]/src/components/live-sports/SportsSchedule.tsx",
                                                    lineNumber: 659,
                                                    columnNumber: 19
                                                }, this)
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/src/components/live-sports/SportsSchedule.tsx",
                                            lineNumber: 657,
                                            columnNumber: 17
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/src/components/live-sports/SportsSchedule.tsx",
                                    lineNumber: 640,
                                    columnNumber: 15
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("a", {
                                    className: "sports-card__book",
                                    href: buildBookingUrl(item, bookingContext),
                                    children: "Book a Table"
                                }, void 0, false, {
                                    fileName: "[project]/src/components/live-sports/SportsSchedule.tsx",
                                    lineNumber: 662,
                                    columnNumber: 15
                                }, this)
                            ]
                        }, item.id || `${item.competition}-${item.start}-${i}`, true, {
                            fileName: "[project]/src/components/live-sports/SportsSchedule.tsx",
                            lineNumber: 631,
                            columnNumber: 13
                        }, this))
                }, void 0, false, {
                    fileName: "[project]/src/components/live-sports/SportsSchedule.tsx",
                    lineNumber: 629,
                    columnNumber: 9
                }, this),
                !loading && filtered.length === 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                    className: "sports-empty",
                    children: "No fixtures match these filters. Try another sport or month."
                }, void 0, false, {
                    fileName: "[project]/src/components/live-sports/SportsSchedule.tsx",
                    lineNumber: 670,
                    columnNumber: 11
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "sports-table-wrap",
                    "aria-label": "Fixtures table",
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("table", {
                        className: "sports-table",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("caption", {
                                className: "sr-only",
                                children: "Live and upcoming sports fixture list"
                            }, void 0, false, {
                                fileName: "[project]/src/components/live-sports/SportsSchedule.tsx",
                                lineNumber: 675,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("thead", {
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("tr", {
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("th", {
                                            scope: "col",
                                            children: "Sport"
                                        }, void 0, false, {
                                            fileName: "[project]/src/components/live-sports/SportsSchedule.tsx",
                                            lineNumber: 678,
                                            columnNumber: 17
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("th", {
                                            scope: "col",
                                            children: "Date"
                                        }, void 0, false, {
                                            fileName: "[project]/src/components/live-sports/SportsSchedule.tsx",
                                            lineNumber: 679,
                                            columnNumber: 17
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("th", {
                                            scope: "col",
                                            children: "Competition / Event"
                                        }, void 0, false, {
                                            fileName: "[project]/src/components/live-sports/SportsSchedule.tsx",
                                            lineNumber: 680,
                                            columnNumber: 17
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("th", {
                                            scope: "col",
                                            children: "Teams"
                                        }, void 0, false, {
                                            fileName: "[project]/src/components/live-sports/SportsSchedule.tsx",
                                            lineNumber: 681,
                                            columnNumber: 17
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("th", {
                                            scope: "col",
                                            children: "Venue"
                                        }, void 0, false, {
                                            fileName: "[project]/src/components/live-sports/SportsSchedule.tsx",
                                            lineNumber: 682,
                                            columnNumber: 17
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("th", {
                                            scope: "col",
                                            children: "UAE Time"
                                        }, void 0, false, {
                                            fileName: "[project]/src/components/live-sports/SportsSchedule.tsx",
                                            lineNumber: 683,
                                            columnNumber: 17
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("th", {
                                            scope: "col",
                                            children: "Channel"
                                        }, void 0, false, {
                                            fileName: "[project]/src/components/live-sports/SportsSchedule.tsx",
                                            lineNumber: 684,
                                            columnNumber: 17
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("th", {
                                            scope: "col",
                                            children: "Status"
                                        }, void 0, false, {
                                            fileName: "[project]/src/components/live-sports/SportsSchedule.tsx",
                                            lineNumber: 685,
                                            columnNumber: 17
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/src/components/live-sports/SportsSchedule.tsx",
                                    lineNumber: 677,
                                    columnNumber: 15
                                }, this)
                            }, void 0, false, {
                                fileName: "[project]/src/components/live-sports/SportsSchedule.tsx",
                                lineNumber: 676,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("tbody", {
                                children: pageItems.map((item, i)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("tr", {
                                        className: `sports-table__row sports-table__row--${item.sport}`,
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("td", {
                                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                    className: `sports-card__sport sports-card__sport--${item.sport}`,
                                                    children: item.sport === "football" ? "Football" : "Cricket"
                                                }, void 0, false, {
                                                    fileName: "[project]/src/components/live-sports/SportsSchedule.tsx",
                                                    lineNumber: 692,
                                                    columnNumber: 21
                                                }, this)
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/live-sports/SportsSchedule.tsx",
                                                lineNumber: 691,
                                                columnNumber: 19
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("td", {
                                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("time", {
                                                    dateTime: item.start,
                                                    children: formatDateRange(item.start, item.end)
                                                }, void 0, false, {
                                                    fileName: "[project]/src/components/live-sports/SportsSchedule.tsx",
                                                    lineNumber: 697,
                                                    columnNumber: 21
                                                }, this)
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/live-sports/SportsSchedule.tsx",
                                                lineNumber: 696,
                                                columnNumber: 19
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("td", {
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("strong", {
                                                        children: item.competition
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/components/live-sports/SportsSchedule.tsx",
                                                        lineNumber: 700,
                                                        columnNumber: 21
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                        className: "sports-table__sub",
                                                        children: item.event
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/components/live-sports/SportsSchedule.tsx",
                                                        lineNumber: 701,
                                                        columnNumber: 21
                                                    }, this)
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/src/components/live-sports/SportsSchedule.tsx",
                                                lineNumber: 699,
                                                columnNumber: 19
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("td", {
                                                children: item.teams
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/live-sports/SportsSchedule.tsx",
                                                lineNumber: 703,
                                                columnNumber: 19
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("td", {
                                                children: item.venue
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/live-sports/SportsSchedule.tsx",
                                                lineNumber: 704,
                                                columnNumber: 19
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("td", {
                                                children: item.time
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/live-sports/SportsSchedule.tsx",
                                                lineNumber: 705,
                                                columnNumber: 19
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("td", {
                                                children: item.channel
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/live-sports/SportsSchedule.tsx",
                                                lineNumber: 706,
                                                columnNumber: 19
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("td", {
                                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                    className: `sports-card__status sports-card__status--${item.status}`,
                                                    children: statusLabel(item.status)
                                                }, void 0, false, {
                                                    fileName: "[project]/src/components/live-sports/SportsSchedule.tsx",
                                                    lineNumber: 708,
                                                    columnNumber: 21
                                                }, this)
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/live-sports/SportsSchedule.tsx",
                                                lineNumber: 707,
                                                columnNumber: 19
                                            }, this)
                                        ]
                                    }, `row-${item.id || `${item.competition}-${item.start}-${i}`}`, true, {
                                        fileName: "[project]/src/components/live-sports/SportsSchedule.tsx",
                                        lineNumber: 690,
                                        columnNumber: 17
                                    }, this))
                            }, void 0, false, {
                                fileName: "[project]/src/components/live-sports/SportsSchedule.tsx",
                                lineNumber: 688,
                                columnNumber: 13
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/live-sports/SportsSchedule.tsx",
                        lineNumber: 674,
                        columnNumber: 11
                    }, this)
                }, void 0, false, {
                    fileName: "[project]/src/components/live-sports/SportsSchedule.tsx",
                    lineNumber: 673,
                    columnNumber: 9
                }, this),
                totalPages > 1 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("nav", {
                    className: "sports-pagination",
                    "aria-label": "Fixtures pagination",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                            type: "button",
                            className: "sports-pagination__btn",
                            onClick: ()=>changePage(currentPage - 1),
                            disabled: currentPage === 1,
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
                                    width: "16",
                                    height: "16",
                                    viewBox: "0 0 24 24",
                                    fill: "none",
                                    stroke: "currentColor",
                                    strokeWidth: "2",
                                    "aria-hidden": "true",
                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                                        d: "M15 18l-6-6 6-6"
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/live-sports/SportsSchedule.tsx",
                                        lineNumber: 720,
                                        columnNumber: 17
                                    }, this)
                                }, void 0, false, {
                                    fileName: "[project]/src/components/live-sports/SportsSchedule.tsx",
                                    lineNumber: 719,
                                    columnNumber: 15
                                }, this),
                                "Prev"
                            ]
                        }, void 0, true, {
                            fileName: "[project]/src/components/live-sports/SportsSchedule.tsx",
                            lineNumber: 718,
                            columnNumber: 13
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "sports-pagination__pages",
                            children: pageButtons.map((p, i)=>p === "gap" ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                    className: "sports-pagination__ellipsis",
                                    "aria-hidden": "true",
                                    children: "…"
                                }, `gap-${i}`, false, {
                                    fileName: "[project]/src/components/live-sports/SportsSchedule.tsx",
                                    lineNumber: 727,
                                    columnNumber: 19
                                }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                    type: "button",
                                    className: `sports-pagination__page${p === currentPage ? " is-active" : ""}`,
                                    "aria-current": p === currentPage ? "page" : undefined,
                                    onClick: ()=>changePage(p),
                                    children: p
                                }, p, false, {
                                    fileName: "[project]/src/components/live-sports/SportsSchedule.tsx",
                                    lineNumber: 731,
                                    columnNumber: 19
                                }, this))
                        }, void 0, false, {
                            fileName: "[project]/src/components/live-sports/SportsSchedule.tsx",
                            lineNumber: 724,
                            columnNumber: 13
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                            type: "button",
                            className: "sports-pagination__btn",
                            onClick: ()=>changePage(currentPage + 1),
                            disabled: currentPage === totalPages,
                            children: [
                                "Next",
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
                                    width: "16",
                                    height: "16",
                                    viewBox: "0 0 24 24",
                                    fill: "none",
                                    stroke: "currentColor",
                                    strokeWidth: "2",
                                    "aria-hidden": "true",
                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                                        d: "M9 18l6-6-6-6"
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/live-sports/SportsSchedule.tsx",
                                        lineNumber: 746,
                                        columnNumber: 17
                                    }, this)
                                }, void 0, false, {
                                    fileName: "[project]/src/components/live-sports/SportsSchedule.tsx",
                                    lineNumber: 745,
                                    columnNumber: 15
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/src/components/live-sports/SportsSchedule.tsx",
                            lineNumber: 743,
                            columnNumber: 13
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/components/live-sports/SportsSchedule.tsx",
                    lineNumber: 717,
                    columnNumber: 11
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/live-sports/SportsSchedule.tsx",
            lineNumber: 460,
            columnNumber: 7
        }, this)
    }, void 0, false, {
        fileName: "[project]/src/components/live-sports/SportsSchedule.tsx",
        lineNumber: 459,
        columnNumber: 5
    }, this);
}
}),
"[project]/src/data/sports-schedule.json.[json].cjs [app-ssr] (ecmascript)", ((__turbopack_context__, module, exports) => {

module.exports = JSON.parse("{\"fixtures\":[{\"sport\":\"football\",\"month\":\"August\",\"start\":\"2026-08-04\",\"end\":\"2026-08-05\",\"competition\":\"UEFA Champions League\",\"event\":\"Third qualifying round – first legs\",\"teams\":\"Various\",\"venue\":\"Europe\",\"time\":\"TBC\",\"channel\":\"beIN SPORTS\"},{\"sport\":\"football\",\"month\":\"August\",\"start\":\"2026-08-11\",\"end\":\"2026-08-11\",\"competition\":\"UEFA Champions League\",\"event\":\"Third qualifying round – second legs\",\"teams\":\"Various\",\"venue\":\"Europe\",\"time\":\"TBC\",\"channel\":\"beIN SPORTS\"},{\"sport\":\"football\",\"month\":\"August\",\"start\":\"2026-08-12\",\"end\":\"2026-08-12\",\"competition\":\"UEFA Super Cup\",\"event\":\"Final\",\"teams\":\"TBC\",\"venue\":\"Salzburg, Austria\",\"time\":\"TBC\",\"channel\":\"beIN SPORTS\"},{\"sport\":\"football\",\"month\":\"August\",\"start\":\"2026-08-15\",\"end\":\"2026-08-15\",\"competition\":\"European Domestic Leagues\",\"event\":\"La Liga – Matchday 1\",\"teams\":\"Alavés vs Getafe\",\"venue\":\"Mendizorrotza, Vitoria-Gasteiz\",\"time\":\"9:30 PM\",\"channel\":\"beIN SPORTS\"},{\"sport\":\"football\",\"month\":\"August\",\"start\":\"2026-08-15\",\"end\":\"2026-08-15\",\"competition\":\"European Domestic Leagues\",\"event\":\"La Liga – Matchday 1\",\"teams\":\"Sevilla vs Rayo Vallecano\",\"venue\":\"Ramón Sánchez-Pizjuán, Seville\",\"time\":\"11:30 PM\",\"channel\":\"beIN SPORTS\"},{\"sport\":\"football\",\"month\":\"August\",\"start\":\"2026-08-16\",\"end\":\"2026-08-16\",\"competition\":\"European Domestic Leagues\",\"event\":\"La Liga – Matchday 1\",\"teams\":\"Celta Vigo vs Osasuna\",\"venue\":\"Balaídos, Vigo\",\"time\":\"11:30 PM\",\"channel\":\"beIN SPORTS\"},{\"sport\":\"football\",\"month\":\"August\",\"start\":\"2026-08-16\",\"end\":\"2026-08-16\",\"competition\":\"European Domestic Leagues\",\"event\":\"La Liga – Matchday 1\",\"teams\":\"Espanyol vs Levante\",\"venue\":\"RCDE Stadium, Barcelona\",\"time\":\"9:00 PM\",\"channel\":\"beIN SPORTS\"},{\"sport\":\"football\",\"month\":\"August\",\"start\":\"2026-08-16\",\"end\":\"2026-08-16\",\"competition\":\"European Domestic Leagues\",\"event\":\"La Liga – Matchday 1\",\"teams\":\"Racing Santander vs Villarreal\",\"venue\":\"El Sardinero, Santander\",\"time\":\"7:00 PM\",\"channel\":\"beIN SPORTS\"},{\"sport\":\"football\",\"month\":\"August\",\"start\":\"2026-08-17\",\"end\":\"2026-08-17\",\"competition\":\"European Domestic Leagues\",\"event\":\"La Liga – Matchday 1\",\"teams\":\"Deportivo La Coruña vs Elche\",\"venue\":\"Riazor, A Coruña\",\"time\":\"11:00 PM\",\"channel\":\"beIN SPORTS\"},{\"sport\":\"football\",\"month\":\"August\",\"start\":\"2026-08-18\",\"end\":\"2026-08-19\",\"competition\":\"UEFA Champions League\",\"event\":\"Play-off round – first legs\",\"teams\":\"Various\",\"venue\":\"Europe\",\"time\":\"TBC\",\"channel\":\"beIN SPORTS\"},{\"sport\":\"cricket\",\"month\":\"August\",\"start\":\"2026-08-19\",\"end\":\"2026-08-23\",\"competition\":\"Pakistan tour of England\",\"event\":\"1st Test\",\"teams\":\"England vs Pakistan\",\"venue\":\"Headingley, Leeds\",\"time\":\"TBC\",\"channel\":\"CricLife / STARZPLAY – verify closer to match\"},{\"sport\":\"football\",\"month\":\"August\",\"start\":\"2026-08-19\",\"end\":\"2026-08-19\",\"competition\":\"European Domestic Leagues\",\"event\":\"La Liga – Matchday 1\",\"teams\":\"Atlético Madrid vs Málaga\",\"venue\":\"Metropolitano, Madrid\",\"time\":\"11:00 PM\",\"channel\":\"beIN SPORTS\"},{\"sport\":\"football\",\"month\":\"August\",\"start\":\"2026-08-20\",\"end\":\"2026-08-20\",\"competition\":\"European Domestic Leagues\",\"event\":\"La Liga – Matchday 2\",\"teams\":\"Rayo Vallecano vs Alavés\",\"venue\":\"Estadio de Vallecas, Madrid\",\"time\":\"11:00 PM\",\"channel\":\"beIN SPORTS\"},{\"sport\":\"football\",\"month\":\"August\",\"start\":\"2026-08-21\",\"end\":\"2026-08-21\",\"competition\":\"European Domestic Leagues\",\"event\":\"La Liga – Matchday 2\",\"teams\":\"Real Betis vs Real Sociedad\",\"venue\":\"Benito Villamarín, Seville\",\"time\":\"11:00 PM\",\"channel\":\"beIN SPORTS\"},{\"sport\":\"football\",\"month\":\"August\",\"start\":\"2026-08-21\",\"end\":\"2026-08-21\",\"competition\":\"European Domestic Leagues\",\"event\":\"Ligue 1 – Matchday 1\",\"teams\":\"Marseille vs Strasbourg\",\"venue\":\"Stade Vélodrome, Marseille\",\"time\":\"10:45 PM\",\"channel\":\"beIN SPORTS\"},{\"sport\":\"football\",\"month\":\"August\",\"start\":\"2026-08-21\",\"end\":\"2026-08-21\",\"competition\":\"European Domestic Leagues\",\"event\":\"Premier League – Matchweek 1\",\"teams\":\"Arsenal vs Coventry City\",\"venue\":\"Emirates Stadium, London\",\"time\":\"11:00 PM\",\"channel\":\"beIN SPORTS\"},{\"sport\":\"football\",\"month\":\"August\",\"start\":\"2026-08-22\",\"end\":\"2026-08-22\",\"competition\":\"European Domestic Leagues\",\"event\":\"La Liga – Matchday 2\",\"teams\":\"Athletic Bilbao vs Sevilla\",\"venue\":\"San Mamés, Bilbao\",\"time\":\"7:00 PM\",\"channel\":\"beIN SPORTS\"},{\"sport\":\"football\",\"month\":\"August\",\"start\":\"2026-08-22\",\"end\":\"2026-08-22\",\"competition\":\"European Domestic Leagues\",\"event\":\"La Liga – Matchday 2\",\"teams\":\"Espanyol vs Real Madrid\",\"venue\":\"RCDE Stadium, Barcelona\",\"time\":\"11:30 PM\",\"channel\":\"beIN SPORTS\"},{\"sport\":\"football\",\"month\":\"August\",\"start\":\"2026-08-22\",\"end\":\"2026-08-22\",\"competition\":\"European Domestic Leagues\",\"event\":\"La Liga – Matchday 2\",\"teams\":\"Valencia vs Celta Vigo\",\"venue\":\"Mestalla, Valencia\",\"time\":\"9:30 PM\",\"channel\":\"beIN SPORTS\"},{\"sport\":\"football\",\"month\":\"August\",\"start\":\"2026-08-22\",\"end\":\"2026-08-22\",\"competition\":\"European Domestic Leagues\",\"event\":\"Ligue 1 – Matchday 1\",\"teams\":\"Le Mans vs Brest\",\"venue\":\"MMArena, Le Mans\",\"time\":\"10:45 PM\",\"channel\":\"beIN SPORTS\"},{\"sport\":\"football\",\"month\":\"August\",\"start\":\"2026-08-22\",\"end\":\"2026-08-22\",\"competition\":\"European Domestic Leagues\",\"event\":\"Ligue 1 – Matchday 1\",\"teams\":\"Lens vs Auxerre\",\"venue\":\"Stade Bollaert-Delelis, Lens\",\"time\":\"7:15 PM\",\"channel\":\"beIN SPORTS\"},{\"sport\":\"football\",\"month\":\"August\",\"start\":\"2026-08-22\",\"end\":\"2026-08-22\",\"competition\":\"European Domestic Leagues\",\"event\":\"Ligue 1 – Matchday 1\",\"teams\":\"Nice vs Lorient\",\"venue\":\"Allianz Riviera, Nice\",\"time\":\"10:45 PM\",\"channel\":\"beIN SPORTS\"},{\"sport\":\"football\",\"month\":\"August\",\"start\":\"2026-08-22\",\"end\":\"2026-08-22\",\"competition\":\"European Domestic Leagues\",\"event\":\"Ligue 1 – Matchday 1\",\"teams\":\"Toulouse vs Lyon\",\"venue\":\"Stadium de Toulouse\",\"time\":\"10:45 PM\",\"channel\":\"beIN SPORTS\"},{\"sport\":\"football\",\"month\":\"August\",\"start\":\"2026-08-22\",\"end\":\"2026-08-22\",\"competition\":\"European Domestic Leagues\",\"event\":\"Ligue 1 – Matchday 1\",\"teams\":\"Troyes vs Paris FC\",\"venue\":\"Stade de l'Aube, Troyes\",\"time\":\"10:45 PM\",\"channel\":\"beIN SPORTS\"},{\"sport\":\"football\",\"month\":\"August\",\"start\":\"2026-08-22\",\"end\":\"2026-08-22\",\"competition\":\"European Domestic Leagues\",\"event\":\"Premier League – Matchweek 1\",\"teams\":\"Brentford vs Tottenham Hotspur\",\"venue\":\"Gtech Community Stadium, London\",\"time\":\"8:30 PM\",\"channel\":\"beIN SPORTS\"},{\"sport\":\"football\",\"month\":\"August\",\"start\":\"2026-08-22\",\"end\":\"2026-08-22\",\"competition\":\"European Domestic Leagues\",\"event\":\"Premier League – Matchweek 1\",\"teams\":\"Everton vs Crystal Palace\",\"venue\":\"Hill Dickinson Stadium, Liverpool\",\"time\":\"6:00 PM\",\"channel\":\"beIN SPORTS\"},{\"sport\":\"football\",\"month\":\"August\",\"start\":\"2026-08-22\",\"end\":\"2026-08-22\",\"competition\":\"European Domestic Leagues\",\"event\":\"Premier League – Matchweek 1\",\"teams\":\"Hull City vs Manchester United\",\"venue\":\"MKM Stadium, Hull\",\"time\":\"3:30 PM\",\"channel\":\"beIN SPORTS\"},{\"sport\":\"football\",\"month\":\"August\",\"start\":\"2026-08-22\",\"end\":\"2026-08-22\",\"competition\":\"European Domestic Leagues\",\"event\":\"Premier League – Matchweek 1\",\"teams\":\"Ipswich Town vs Sunderland\",\"venue\":\"Portman Road, Ipswich\",\"time\":\"6:00 PM\",\"channel\":\"beIN SPORTS\"},{\"sport\":\"football\",\"month\":\"August\",\"start\":\"2026-08-22\",\"end\":\"2026-08-22\",\"competition\":\"European Domestic Leagues\",\"event\":\"Premier League – Matchweek 1\",\"teams\":\"Nottingham Forest vs Leeds United\",\"venue\":\"City Ground, Nottingham\",\"time\":\"6:00 PM\",\"channel\":\"beIN SPORTS\"},{\"sport\":\"football\",\"month\":\"August\",\"start\":\"2026-08-23\",\"end\":\"2026-08-23\",\"competition\":\"European Domestic Leagues\",\"event\":\"La Liga – Matchday 2\",\"teams\":\"Atlético Madrid vs Villarreal\",\"venue\":\"Metropolitano, Madrid\",\"time\":\"7:00 PM\",\"channel\":\"beIN SPORTS\"},{\"sport\":\"football\",\"month\":\"August\",\"start\":\"2026-08-23\",\"end\":\"2026-08-23\",\"competition\":\"European Domestic Leagues\",\"event\":\"La Liga – Matchday 2\",\"teams\":\"Elche vs Barcelona\",\"venue\":\"Martínez Valero, Elche\",\"time\":\"11:30 PM\",\"channel\":\"beIN SPORTS\"},{\"sport\":\"football\",\"month\":\"August\",\"start\":\"2026-08-23\",\"end\":\"2026-08-23\",\"competition\":\"European Domestic Leagues\",\"event\":\"La Liga – Matchday 2\",\"teams\":\"Getafe vs Racing Santander\",\"venue\":\"Coliseum, Getafe\",\"time\":\"9:30 PM\",\"channel\":\"beIN SPORTS\"},{\"sport\":\"football\",\"month\":\"August\",\"start\":\"2026-08-23\",\"end\":\"2026-08-23\",\"competition\":\"European Domestic Leagues\",\"event\":\"Ligue 1 – Matchday 1\",\"teams\":\"Angers vs Lille\",\"venue\":\"Stade Raymond Kopa, Angers\",\"time\":\"5:00 PM\",\"channel\":\"beIN SPORTS\"},{\"sport\":\"football\",\"month\":\"August\",\"start\":\"2026-08-23\",\"end\":\"2026-08-23\",\"competition\":\"European Domestic Leagues\",\"event\":\"Ligue 1 – Matchday 1\",\"teams\":\"Le Havre vs Monaco\",\"venue\":\"Stade Océane, Le Havre\",\"time\":\"7:15 PM\",\"channel\":\"beIN SPORTS\"},{\"sport\":\"football\",\"month\":\"August\",\"start\":\"2026-08-23\",\"end\":\"2026-08-23\",\"competition\":\"European Domestic Leagues\",\"event\":\"Ligue 1 – Matchday 1\",\"teams\":\"Paris Saint-Germain vs Rennes\",\"venue\":\"Parc des Princes, Paris\",\"time\":\"10:45 PM\",\"channel\":\"beIN SPORTS\"},{\"sport\":\"football\",\"month\":\"August\",\"start\":\"2026-08-23\",\"end\":\"2026-08-23\",\"competition\":\"European Domestic Leagues\",\"event\":\"Premier League – Matchweek 1\",\"teams\":\"Brighton vs Aston Villa\",\"venue\":\"Amex Stadium, Brighton\",\"time\":\"5:00 PM\",\"channel\":\"beIN SPORTS\"},{\"sport\":\"football\",\"month\":\"August\",\"start\":\"2026-08-23\",\"end\":\"2026-08-23\",\"competition\":\"European Domestic Leagues\",\"event\":\"Premier League – Matchweek 1\",\"teams\":\"Manchester City vs Bournemouth\",\"venue\":\"Etihad Stadium, Manchester\",\"time\":\"5:00 PM\",\"channel\":\"beIN SPORTS\"},{\"sport\":\"football\",\"month\":\"August\",\"start\":\"2026-08-23\",\"end\":\"2026-08-23\",\"competition\":\"European Domestic Leagues\",\"event\":\"Premier League – Matchweek 1\",\"teams\":\"Newcastle United vs Liverpool\",\"venue\":\"St James' Park, Newcastle\",\"time\":\"7:30 PM\",\"channel\":\"beIN SPORTS\"},{\"sport\":\"football\",\"month\":\"August\",\"start\":\"2026-08-24\",\"end\":\"2026-08-24\",\"competition\":\"European Domestic Leagues\",\"event\":\"La Liga – Matchday 2\",\"teams\":\"Málaga vs Deportivo La Coruña\",\"venue\":\"La Rosaleda, Málaga\",\"time\":\"11:30 PM\",\"channel\":\"beIN SPORTS\"},{\"sport\":\"football\",\"month\":\"August\",\"start\":\"2026-08-24\",\"end\":\"2026-08-24\",\"competition\":\"European Domestic Leagues\",\"event\":\"La Liga – Matchday 2\",\"teams\":\"Osasuna vs Levante\",\"venue\":\"El Sadar, Pamplona\",\"time\":\"9:30 PM\",\"channel\":\"beIN SPORTS\"},{\"sport\":\"football\",\"month\":\"August\",\"start\":\"2026-08-24\",\"end\":\"2026-08-24\",\"competition\":\"European Domestic Leagues\",\"event\":\"Premier League – Matchweek 1\",\"teams\":\"Fulham vs Chelsea\",\"venue\":\"Craven Cottage, London\",\"time\":\"11:00 PM\",\"channel\":\"beIN SPORTS\"},{\"sport\":\"football\",\"month\":\"August\",\"start\":\"2026-08-25\",\"end\":\"2026-08-25\",\"competition\":\"European Domestic Leagues\",\"event\":\"La Liga – Matchday 1\",\"teams\":\"Valencia vs Real Betis\",\"venue\":\"Mestalla, Valencia\",\"time\":\"11:00 PM\",\"channel\":\"beIN SPORTS\"},{\"sport\":\"football\",\"month\":\"August\",\"start\":\"2026-08-25\",\"end\":\"2026-08-26\",\"competition\":\"UEFA Champions League\",\"event\":\"Play-off round – second legs\",\"teams\":\"Various\",\"venue\":\"Europe\",\"time\":\"TBC\",\"channel\":\"beIN SPORTS\"},{\"sport\":\"football\",\"month\":\"August\",\"start\":\"2026-08-26\",\"end\":\"2026-08-26\",\"competition\":\"European Domestic Leagues\",\"event\":\"La Liga – Matchday 1\",\"teams\":\"Real Madrid vs Real Sociedad\",\"venue\":\"Santiago Bernabéu, Madrid\",\"time\":\"11:00 PM\",\"channel\":\"beIN SPORTS\"},{\"sport\":\"cricket\",\"month\":\"August\",\"start\":\"2026-08-27\",\"end\":\"2026-08-31\",\"competition\":\"Pakistan tour of England\",\"event\":\"2nd Test\",\"teams\":\"England vs Pakistan\",\"venue\":\"Lord's, London\",\"time\":\"TBC\",\"channel\":\"CricLife / STARZPLAY – verify closer to match\"},{\"sport\":\"football\",\"month\":\"August\",\"start\":\"2026-08-27\",\"end\":\"2026-08-27\",\"competition\":\"European Domestic Leagues\",\"event\":\"La Liga – Matchday 1\",\"teams\":\"Barcelona vs Athletic Bilbao\",\"venue\":\"Spotify Camp Nou, Barcelona\",\"time\":\"11:00 PM\",\"channel\":\"beIN SPORTS\"},{\"sport\":\"football\",\"month\":\"August\",\"start\":\"2026-08-27\",\"end\":\"2026-08-27\",\"competition\":\"UEFA Champions League\",\"event\":\"League phase draw\",\"teams\":\"36 clubs\",\"venue\":\"Monaco / UEFA HQ\",\"time\":\"TBC\",\"channel\":\"beIN SPORTS / UEFA platforms\"},{\"sport\":\"football\",\"month\":\"August\",\"start\":\"2026-08-28\",\"end\":\"2026-08-28\",\"competition\":\"European Domestic Leagues\",\"event\":\"Bundesliga – Matchday 1\",\"teams\":\"Bayern Munich vs VfB Stuttgart\",\"venue\":\"Allianz Arena, Munich\",\"time\":\"10:30 PM\",\"channel\":\"beIN SPORTS\"},{\"sport\":\"football\",\"month\":\"August\",\"start\":\"2026-08-28\",\"end\":\"2026-08-28\",\"competition\":\"European Domestic Leagues\",\"event\":\"Ligue 1 – Matchday 2\",\"teams\":\"Lille vs Paris Saint-Germain\",\"venue\":\"Stade Pierre-Mauroy, Lille\",\"time\":\"10:45 PM\",\"channel\":\"beIN SPORTS\"},{\"sport\":\"football\",\"month\":\"August\",\"start\":\"2026-08-28\",\"end\":\"2026-08-28\",\"competition\":\"European Domestic Leagues\",\"event\":\"Premier League – Matchweek 2\",\"teams\":\"Crystal Palace vs Manchester City\",\"venue\":\"Selhurst Park, London\",\"time\":\"11:00 PM\",\"channel\":\"beIN SPORTS\"},{\"sport\":\"football\",\"month\":\"August\",\"start\":\"2026-08-29\",\"end\":\"2026-08-29\",\"competition\":\"European Domestic Leagues\",\"event\":\"Bundesliga – Matchday 1\",\"teams\":\"Borussia Dortmund vs Hamburger SV\",\"venue\":\"Signal Iduna Park, Dortmund\",\"time\":\"8:30 PM\",\"channel\":\"beIN SPORTS\"},{\"sport\":\"football\",\"month\":\"August\",\"start\":\"2026-08-29\",\"end\":\"2026-08-29\",\"competition\":\"European Domestic Leagues\",\"event\":\"Bundesliga – Matchday 1\",\"teams\":\"Elversberg vs Bayer Leverkusen\",\"venue\":\"Waldstadion an der Kaiserlinde\",\"time\":\"5:30 PM\",\"channel\":\"beIN SPORTS\"},{\"sport\":\"football\",\"month\":\"August\",\"start\":\"2026-08-29\",\"end\":\"2026-08-29\",\"competition\":\"European Domestic Leagues\",\"event\":\"Bundesliga – Matchday 1\",\"teams\":\"Köln vs Hoffenheim\",\"venue\":\"RheinEnergieStadion, Cologne\",\"time\":\"5:30 PM\",\"channel\":\"beIN SPORTS\"},{\"sport\":\"football\",\"month\":\"August\",\"start\":\"2026-08-29\",\"end\":\"2026-08-29\",\"competition\":\"European Domestic Leagues\",\"event\":\"Bundesliga – Matchday 1\",\"teams\":\"Mainz vs Paderborn\",\"venue\":\"MEWA Arena, Mainz\",\"time\":\"5:30 PM\",\"channel\":\"beIN SPORTS\"},{\"sport\":\"football\",\"month\":\"August\",\"start\":\"2026-08-29\",\"end\":\"2026-08-29\",\"competition\":\"European Domestic Leagues\",\"event\":\"Bundesliga – Matchday 1\",\"teams\":\"RB Leipzig vs Borussia Mönchengladbach\",\"venue\":\"Red Bull Arena, Leipzig\",\"time\":\"5:30 PM\",\"channel\":\"beIN SPORTS\"},{\"sport\":\"football\",\"month\":\"August\",\"start\":\"2026-08-29\",\"end\":\"2026-08-29\",\"competition\":\"European Domestic Leagues\",\"event\":\"Bundesliga – Matchday 1\",\"teams\":\"Union Berlin vs Eintracht Frankfurt\",\"venue\":\"Stadion An der Alten Försterei, Berlin\",\"time\":\"5:30 PM\",\"channel\":\"beIN SPORTS\"},{\"sport\":\"football\",\"month\":\"August\",\"start\":\"2026-08-29\",\"end\":\"2026-08-29\",\"competition\":\"European Domestic Leagues\",\"event\":\"Ligue 1 – Matchday 2\",\"teams\":\"Auxerre vs Angers\",\"venue\":\"Stade Abbé-Deschamps, Auxerre\",\"time\":\"10:45 PM\",\"channel\":\"beIN SPORTS\"},{\"sport\":\"football\",\"month\":\"August\",\"start\":\"2026-08-29\",\"end\":\"2026-08-29\",\"competition\":\"European Domestic Leagues\",\"event\":\"Ligue 1 – Matchday 2\",\"teams\":\"Brest vs Toulouse\",\"venue\":\"Stade Francis-Le Blé, Brest\",\"time\":\"10:45 PM\",\"channel\":\"beIN SPORTS\"},{\"sport\":\"football\",\"month\":\"August\",\"start\":\"2026-08-29\",\"end\":\"2026-08-29\",\"competition\":\"European Domestic Leagues\",\"event\":\"Ligue 1 – Matchday 2\",\"teams\":\"Lorient vs Troyes\",\"venue\":\"Stade du Moustoir, Lorient\",\"time\":\"10:45 PM\",\"channel\":\"beIN SPORTS\"},{\"sport\":\"football\",\"month\":\"August\",\"start\":\"2026-08-29\",\"end\":\"2026-08-29\",\"competition\":\"European Domestic Leagues\",\"event\":\"Ligue 1 – Matchday 2\",\"teams\":\"Lyon vs Le Havre\",\"venue\":\"Groupama Stadium, Lyon\",\"time\":\"10:45 PM\",\"channel\":\"beIN SPORTS\"},{\"sport\":\"football\",\"month\":\"August\",\"start\":\"2026-08-29\",\"end\":\"2026-08-29\",\"competition\":\"European Domestic Leagues\",\"event\":\"Ligue 1 – Matchday 2\",\"teams\":\"Strasbourg vs Lens\",\"venue\":\"Stade de la Meinau, Strasbourg\",\"time\":\"7:15 PM\",\"channel\":\"beIN SPORTS\"},{\"sport\":\"football\",\"month\":\"August\",\"start\":\"2026-08-29\",\"end\":\"2026-08-29\",\"competition\":\"European Domestic Leagues\",\"event\":\"Premier League – Matchweek 2\",\"teams\":\"Bournemouth vs Everton\",\"venue\":\"Vitality Stadium, Bournemouth\",\"time\":\"6:00 PM\",\"channel\":\"beIN SPORTS\"},{\"sport\":\"football\",\"month\":\"August\",\"start\":\"2026-08-29\",\"end\":\"2026-08-29\",\"competition\":\"European Domestic Leagues\",\"event\":\"Premier League – Matchweek 2\",\"teams\":\"Coventry City vs Hull City\",\"venue\":\"Coventry Building Society Arena\",\"time\":\"6:00 PM\",\"channel\":\"beIN SPORTS\"},{\"sport\":\"football\",\"month\":\"August\",\"start\":\"2026-08-29\",\"end\":\"2026-08-29\",\"competition\":\"European Domestic Leagues\",\"event\":\"Premier League – Matchweek 2\",\"teams\":\"Liverpool vs Nottingham Forest\",\"venue\":\"Anfield, Liverpool\",\"time\":\"3:30 PM\",\"channel\":\"beIN SPORTS\"},{\"sport\":\"football\",\"month\":\"August\",\"start\":\"2026-08-29\",\"end\":\"2026-08-29\",\"competition\":\"European Domestic Leagues\",\"event\":\"Premier League – Matchweek 2\",\"teams\":\"Tottenham Hotspur vs Newcastle United\",\"venue\":\"Tottenham Hotspur Stadium, London\",\"time\":\"8:30 PM\",\"channel\":\"beIN SPORTS\"},{\"sport\":\"football\",\"month\":\"August\",\"start\":\"2026-08-30\",\"end\":\"2026-08-30\",\"competition\":\"European Domestic Leagues\",\"event\":\"Bundesliga – Matchday 1\",\"teams\":\"Augsburg vs Schalke 04\",\"venue\":\"WWK Arena, Augsburg\",\"time\":\"7:30 PM\",\"channel\":\"beIN SPORTS\"},{\"sport\":\"football\",\"month\":\"August\",\"start\":\"2026-08-30\",\"end\":\"2026-08-30\",\"competition\":\"European Domestic Leagues\",\"event\":\"Bundesliga – Matchday 1\",\"teams\":\"Freiburg vs Werder Bremen\",\"venue\":\"Europa-Park Stadion, Freiburg\",\"time\":\"5:30 PM\",\"channel\":\"beIN SPORTS\"},{\"sport\":\"football\",\"month\":\"August\",\"start\":\"2026-08-30\",\"end\":\"2026-08-30\",\"competition\":\"European Domestic Leagues\",\"event\":\"Ligue 1 – Matchday 2\",\"teams\":\"Monaco vs Marseille\",\"venue\":\"Stade Louis II, Monaco\",\"time\":\"10:45 PM\",\"channel\":\"beIN SPORTS\"},{\"sport\":\"football\",\"month\":\"August\",\"start\":\"2026-08-30\",\"end\":\"2026-08-30\",\"competition\":\"European Domestic Leagues\",\"event\":\"Ligue 1 – Matchday 2\",\"teams\":\"Paris FC vs Nice\",\"venue\":\"Stade Jean-Bouin, Paris\",\"time\":\"5:00 PM\",\"channel\":\"beIN SPORTS\"},{\"sport\":\"football\",\"month\":\"August\",\"start\":\"2026-08-30\",\"end\":\"2026-08-30\",\"competition\":\"European Domestic Leagues\",\"event\":\"Ligue 1 – Matchday 2\",\"teams\":\"Rennes vs Le Mans\",\"venue\":\"Roazhon Park, Rennes\",\"time\":\"7:15 PM\",\"channel\":\"beIN SPORTS\"},{\"sport\":\"football\",\"month\":\"August\",\"start\":\"2026-08-30\",\"end\":\"2026-08-30\",\"competition\":\"European Domestic Leagues\",\"event\":\"Premier League – Matchweek 2\",\"teams\":\"Chelsea vs Brighton\",\"venue\":\"Stamford Bridge, London\",\"time\":\"5:00 PM\",\"channel\":\"beIN SPORTS\"},{\"sport\":\"football\",\"month\":\"August\",\"start\":\"2026-08-30\",\"end\":\"2026-08-30\",\"competition\":\"European Domestic Leagues\",\"event\":\"Premier League – Matchweek 2\",\"teams\":\"Leeds United vs Brentford\",\"venue\":\"Elland Road, Leeds\",\"time\":\"5:00 PM\",\"channel\":\"beIN SPORTS\"},{\"sport\":\"football\",\"month\":\"August\",\"start\":\"2026-08-30\",\"end\":\"2026-08-30\",\"competition\":\"European Domestic Leagues\",\"event\":\"Premier League – Matchweek 2\",\"teams\":\"Manchester United vs Ipswich Town\",\"venue\":\"Old Trafford, Manchester\",\"time\":\"7:30 PM\",\"channel\":\"beIN SPORTS\"},{\"sport\":\"football\",\"month\":\"August\",\"start\":\"2026-08-30\",\"end\":\"2026-08-30\",\"competition\":\"European Domestic Leagues\",\"event\":\"Premier League – Matchweek 2\",\"teams\":\"Sunderland vs Fulham\",\"venue\":\"Stadium of Light, Sunderland\",\"time\":\"5:00 PM\",\"channel\":\"beIN SPORTS\"},{\"sport\":\"football\",\"month\":\"August\",\"start\":\"2026-08-31\",\"end\":\"2026-08-31\",\"competition\":\"European Domestic Leagues\",\"event\":\"Premier League – Matchweek 2\",\"teams\":\"Aston Villa vs Arsenal\",\"venue\":\"Villa Park, Birmingham\",\"time\":\"11:00 PM\",\"channel\":\"beIN SPORTS\"},{\"sport\":\"cricket\",\"month\":\"September\",\"start\":\"2026-09-09\",\"end\":\"2026-09-13\",\"competition\":\"Pakistan tour of England\",\"event\":\"3rd Test\",\"teams\":\"England vs Pakistan\",\"venue\":\"Edgbaston, Birmingham\",\"time\":\"TBC\",\"channel\":\"CricLife / STARZPLAY – verify closer to match\"},{\"sport\":\"football\",\"month\":\"September\",\"start\":\"2026-09-09\",\"end\":\"2026-09-09\",\"competition\":\"UEFA Champions League\",\"event\":\"League phase – Matchday 1\",\"teams\":\"Various\",\"venue\":\"Europe\",\"time\":\"Fixture-specific\",\"channel\":\"beIN SPORTS\"},{\"sport\":\"cricket\",\"month\":\"September\",\"start\":\"2026-09-15\",\"end\":\"2026-09-15\",\"competition\":\"Sri Lanka tour of England\",\"event\":\"1st T20I\",\"teams\":\"England vs Sri Lanka\",\"venue\":\"Southampton\",\"time\":\"TBC\",\"channel\":\"CricLife / STARZPLAY – verify closer to match\"},{\"sport\":\"football\",\"month\":\"September\",\"start\":\"2026-09-16\",\"end\":\"2026-09-17\",\"competition\":\"UEFA Europa League\",\"event\":\"League phase – Matchday 1\",\"teams\":\"Various\",\"venue\":\"Europe\",\"time\":\"Fixture-specific\",\"channel\":\"beIN SPORTS\"},{\"sport\":\"cricket\",\"month\":\"September\",\"start\":\"2026-09-17\",\"end\":\"2026-09-17\",\"competition\":\"Sri Lanka tour of England\",\"event\":\"2nd T20I\",\"teams\":\"England vs Sri Lanka\",\"venue\":\"Cardiff\",\"time\":\"TBC\",\"channel\":\"CricLife / STARZPLAY – verify closer to match\"},{\"sport\":\"cricket\",\"month\":\"September\",\"start\":\"2026-09-19\",\"end\":\"2026-09-19\",\"competition\":\"Sri Lanka tour of England\",\"event\":\"3rd T20I\",\"teams\":\"England vs Sri Lanka\",\"venue\":\"Manchester\",\"time\":\"TBC\",\"channel\":\"CricLife / STARZPLAY – verify closer to match\"},{\"sport\":\"cricket\",\"month\":\"September\",\"start\":\"2026-09-22\",\"end\":\"2026-09-27\",\"competition\":\"Sri Lanka tour of England\",\"event\":\"3-match ODI series\",\"teams\":\"England vs Sri Lanka\",\"venue\":\"England\",\"time\":\"TBC\",\"channel\":\"CricLife / STARZPLAY – verify closer to match\"},{\"sport\":\"cricket\",\"month\":\"September\",\"start\":\"2026-09-24\",\"end\":\"2026-09-30\",\"competition\":\"Australia tour of South Africa\",\"event\":\"3-match ODI series\",\"teams\":\"South Africa vs Australia\",\"venue\":\"South Africa\",\"time\":\"TBC\",\"channel\":\"CricLife / STARZPLAY – verify closer to match\"},{\"sport\":\"cricket\",\"month\":\"September\",\"start\":\"2026-09-27\",\"end\":\"2026-09-27\",\"competition\":\"West Indies tour of India\",\"event\":\"1st ODI\",\"teams\":\"India vs West Indies\",\"venue\":\"Trivandrum\",\"time\":\"TBC\",\"channel\":\"CricLife / STARZPLAY – verify closer to match\"},{\"sport\":\"cricket\",\"month\":\"September\",\"start\":\"2026-09-30\",\"end\":\"2026-09-30\",\"competition\":\"West Indies tour of India\",\"event\":\"2nd ODI\",\"teams\":\"India vs West Indies\",\"venue\":\"Guwahati\",\"time\":\"TBC\",\"channel\":\"CricLife / STARZPLAY – verify closer to match\"},{\"sport\":\"football\",\"month\":\"September\",\"start\":\"2026-09-30\",\"end\":\"2026-10-01\",\"competition\":\"UEFA Champions League\",\"event\":\"League phase – Matchday 2\",\"teams\":\"Various\",\"venue\":\"Europe\",\"time\":\"Fixture-specific\",\"channel\":\"beIN SPORTS\"},{\"sport\":\"cricket\",\"month\":\"October\",\"start\":\"2026-10-03\",\"end\":\"2026-10-03\",\"competition\":\"West Indies tour of India\",\"event\":\"3rd ODI\",\"teams\":\"India vs West Indies\",\"venue\":\"New Chandigarh\",\"time\":\"TBC\",\"channel\":\"CricLife / STARZPLAY – verify closer to match\"},{\"sport\":\"cricket\",\"month\":\"October\",\"start\":\"2026-10-09\",\"end\":\"2026-10-31\",\"competition\":\"Australia tour of South Africa\",\"event\":\"3-match Test series\",\"teams\":\"South Africa vs Australia\",\"venue\":\"South Africa\",\"time\":\"TBC\",\"channel\":\"CricLife / STARZPLAY – verify closer to match\"},{\"sport\":\"football\",\"month\":\"October\",\"start\":\"2026-10-15\",\"end\":\"2026-10-15\",\"competition\":\"UEFA Conference League\",\"event\":\"League phase – Matchday 1\",\"teams\":\"Various\",\"venue\":\"Europe\",\"time\":\"Fixture-specific\",\"channel\":\"beIN SPORTS\"},{\"sport\":\"football\",\"month\":\"October\",\"start\":\"2026-10-21\",\"end\":\"2026-10-22\",\"competition\":\"UEFA Champions League\",\"event\":\"League phase – Matchday 3\",\"teams\":\"Various\",\"venue\":\"Europe\",\"time\":\"Fixture-specific\",\"channel\":\"beIN SPORTS\"},{\"sport\":\"cricket\",\"month\":\"October\",\"start\":\"2026-10-22\",\"end\":\"2026-11-01\",\"competition\":\"India tour of New Zealand\",\"event\":\"5-match T20I series\",\"teams\":\"New Zealand vs India\",\"venue\":\"New Zealand\",\"time\":\"TBC\",\"channel\":\"CricLife / STARZPLAY – verify closer to match\"},{\"sport\":\"football\",\"month\":\"November\",\"start\":\"2026-11-04\",\"end\":\"2026-11-05\",\"competition\":\"UEFA Champions League\",\"event\":\"League phase – Matchday 4\",\"teams\":\"Various\",\"venue\":\"Europe\",\"time\":\"Fixture-specific\",\"channel\":\"beIN SPORTS\"},{\"sport\":\"cricket\",\"month\":\"November\",\"start\":\"2026-11-05\",\"end\":\"2026-11-20\",\"competition\":\"India tour of New Zealand\",\"event\":\"3 ODIs and 3 T20Is follow-up window\",\"teams\":\"New Zealand vs India\",\"venue\":\"New Zealand\",\"time\":\"Exact dates TBC\",\"channel\":\"CricLife / STARZPLAY – verify closer to match\"},{\"sport\":\"football\",\"month\":\"November\",\"start\":\"2026-11-12\",\"end\":\"2026-11-17\",\"competition\":\"UEFA Nations League\",\"event\":\"League phase – Matchdays 5 and 6\",\"teams\":\"European national teams\",\"venue\":\"Europe\",\"time\":\"Fixture-specific\",\"channel\":\"beIN SPORTS\"},{\"sport\":\"football\",\"month\":\"November\",\"start\":\"2026-11-24\",\"end\":\"2026-11-25\",\"competition\":\"UEFA Champions League\",\"event\":\"League phase – Matchday 5\",\"teams\":\"Various\",\"venue\":\"Europe\",\"time\":\"Fixture-specific\",\"channel\":\"beIN SPORTS\"},{\"sport\":\"football\",\"month\":\"November\",\"start\":\"2026-11-26\",\"end\":\"2026-11-26\",\"competition\":\"UEFA Europa League / Conference League\",\"event\":\"Matchday 5 / Matchday 4\",\"teams\":\"Various\",\"venue\":\"Europe\",\"time\":\"Fixture-specific\",\"channel\":\"beIN SPORTS\"},{\"sport\":\"football\",\"month\":\"December\",\"start\":\"2026-12-08\",\"end\":\"2026-12-09\",\"competition\":\"UEFA Champions League\",\"event\":\"League phase – Matchday 6\",\"teams\":\"Various\",\"venue\":\"Europe\",\"time\":\"Fixture-specific\",\"channel\":\"beIN SPORTS\"},{\"sport\":\"cricket\",\"month\":\"December\",\"start\":\"2026-12-10\",\"end\":\"2026-12-23\",\"competition\":\"Bangladesh Women tour of New Zealand\",\"event\":\"3 T20Is and 3 ODIs\",\"teams\":\"New Zealand Women vs Bangladesh Women\",\"venue\":\"New Zealand\",\"time\":\"TBC\",\"channel\":\"CricLife / STARZPLAY – verify closer to match\"},{\"sport\":\"football\",\"month\":\"December\",\"start\":\"2026-12-10\",\"end\":\"2026-12-10\",\"competition\":\"UEFA Europa League / Conference League\",\"event\":\"Europa Matchday 6 / Conference Matchday 5\",\"teams\":\"Various\",\"venue\":\"Europe\",\"time\":\"Fixture-specific\",\"channel\":\"beIN SPORTS\"},{\"sport\":\"cricket\",\"month\":\"December\",\"start\":\"2026-12-17\",\"end\":\"2026-12-30\",\"competition\":\"England tour of South Africa\",\"event\":\"First two Tests\",\"teams\":\"South Africa vs England\",\"venue\":\"Johannesburg / Centurion\",\"time\":\"TBC\",\"channel\":\"CricLife / STARZPLAY – verify closer to match\"},{\"sport\":\"football\",\"month\":\"December\",\"start\":\"2026-12-17\",\"end\":\"2026-12-17\",\"competition\":\"UEFA Conference League\",\"event\":\"League phase – Matchday 6\",\"teams\":\"Various\",\"venue\":\"Europe\",\"time\":\"Fixture-specific\",\"channel\":\"beIN SPORTS\"},{\"sport\":\"football\",\"month\":\"December\",\"start\":\"2026-12-20\",\"end\":\"2026-12-31\",\"competition\":\"Premier League and European Leagues\",\"event\":\"Festive league fixtures\",\"teams\":\"Various\",\"venue\":\"Europe\",\"time\":\"Fixture-specific\",\"channel\":\"beIN SPORTS\"}]}");
}),
];

//# sourceMappingURL=src_2057qlv._.js.map