module.exports = [
"[project]/.next-internal/server/app/board-games/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=_next-internal_server_app_board-games_page_actions_1or8txm.js.map