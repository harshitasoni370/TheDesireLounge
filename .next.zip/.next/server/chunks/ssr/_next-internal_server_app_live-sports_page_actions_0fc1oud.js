module.exports=[14093,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_live-sports_page_actions_0fc1oud.js.map