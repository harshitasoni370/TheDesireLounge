module.exports=[37409,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_board-games_page_actions_1or8txm.js.map