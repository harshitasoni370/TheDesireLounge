globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/0cz1d0mv5g_q7.js"
  ],
  "lowPriorityFiles": [
    "static/4xsDnQXJAcFL3j0SeMaHO/_buildManifest.js",
    "static/4xsDnQXJAcFL3j0SeMaHO/_ssgManifest.js",
    "static/4xsDnQXJAcFL3j0SeMaHO/_clientMiddlewareManifest.js"
  ],
  "rootMainFiles": [
    "static/chunks/3s6nzrbk-8mnv.js",
    "static/chunks/2mmpezlrfmbu5.js",
    "static/chunks/1mkbuudhndal5.js",
    "static/chunks/2_2-1c0c4snqt.js",
    "static/chunks/turbopack-2pn8040hjatgw.js"
  ],
  "rootMainFilesTree": {},
  "pagesChunkGroupBootstrapParams": {},
  "chunkLoadingGlobal": "TURBOPACK"
};
