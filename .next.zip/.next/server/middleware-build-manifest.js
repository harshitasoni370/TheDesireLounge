globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/0cz1d0mv5g_q7.js"
  ],
  "lowPriorityFiles": [
    "static/xCcaM3sVQfjo8LcXKPDzB/_buildManifest.js",
    "static/xCcaM3sVQfjo8LcXKPDzB/_ssgManifest.js",
    "static/xCcaM3sVQfjo8LcXKPDzB/_clientMiddlewareManifest.js"
  ],
  "rootMainFiles": [
    "static/chunks/3s6nzrbk-8mnv.js",
    "static/chunks/2mmpezlrfmbu5.js",
    "static/chunks/1mkbuudhndal5.js",
    "static/chunks/2_2-1c0c4snqt.js",
    "static/chunks/turbopack-2pn8040hjatgw.js"
  ],
  "rootMainFilesTree": {},
  "pagesChunkGroupBootstrapParams": {},
  "chunkLoadingGlobal": "TURBOPACK"
};
